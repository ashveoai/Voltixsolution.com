# Voltix Solutions - Complete Project Media & Export Guide

## 1. List of All Website Image URLs

Here are all 14 official High-Resolution image assets used across the Voltix Solutions web application. You can view, download, or reference them individually:

### ☀️ Services Division Images
1. **Solar Solutions (Solar Energy & Panel Systems)**:
   - `https://images.unsplash.com/photo-1508873696983-2df515122519?auto=format&fit=crop&q=80&w=1000`
2. **General Maintenance Services (Facility Maintenance & Care)**:
   - `https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&q=80&w=1000`
3. **Electrical Services (DB Panels, High Voltage Cables)**:
   - `https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&q=80&w=1000`
4. **Engineering Consultations (Technical Audits & MEP)**:
   - `https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=1000`
5. **Plumbing Services (Pipe Laying, Tank Cleaning)**:
   - `https://images.unsplash.com/photo-1505798577917-a65157d3320a?auto=format&fit=crop&q=80&w=1000`
6. **HVAC & AC Services (Cooling, Ductwork, VRF)**:
   - `https://images.unsplash.com/photo-1621905252507-b35492cc74b4?auto=format&fit=crop&q=80&w=1000`
7. **Fire Safety Solutions (Fire Alarms & Extinguishers)**:
   - `https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?auto=format&fit=crop&q=80&w=1000`
8. **CCTV & Security Solutions (4K IP Security Cameras)**:
   - `https://images.unsplash.com/photo-1557597774-9d273605dfa9?auto=format&fit=crop&q=80&w=1000`

---

### 🏭 Industries Served Images
9. **Factories & Industries (Industrial Plants & Textile Mills)**:
   - `https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=1000`
10. **Construction Developments (Infrastructure & Electrification)**:
    - `https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&q=80&w=1000`
11. **Residential Projects (Luxury Villas & Housing)**:
    - `https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1000`
12. **Commercial Buildings (Plazas & Malls)**:
    - `https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1000`
13. **Offices & Corporate Hubs (IT Offices & Call Centers)**:
    - `https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1000`
14. **Retail Outlets & Supermarkets (Stores & Boutiques)**:
    - `https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=1000`

---

## 2. How to Export & Upload to GitHub

You can export this entire codebase directly from AI Studio in 2 easy ways:

### Option A: Export to GitHub / Download ZIP from AI Studio
1. Click on the **Settings / Export** menu icon at the top right of your screen in AI Studio.
2. Choose **Export to GitHub** to push the repository directly into your GitHub account, OR select **Download ZIP** to save the entire source code to your computer.

### Vercel Deployment Settings (404 Fix)
When deploying to Vercel from GitHub:
1. Framework Preset: Select **Vite**
2. Root Directory: `./` (leave default)
3. Build Command: `npm run build`
4. Output Directory: `dist`
5. The included `vercel.json` and `api/index.ts` will automatically route static SPA pages and API routes without any 404 errors!

### Option B: Local Setup & Git Commands
If you download the ZIP or clone the repository:
```bash
# 1. Install dependencies
npm install

# 2. Run local development server
npm run dev

# 3. Build for production
npm run build
```

---

## 3. Key Features Included in Codebase
- **Dual Customer & Owner Views**:
  - **Customer View**: Clean forms, instant confirmation receipts (`#VOLTIX-INQ-XXXX`), and 1-click WhatsApp submission to Voltix dispatch (+92 304 2510042). No customer leads or internal data exposed to public visitors.
  - **Owner Management Portal**: Secured via PIN (Default PIN: `1234`). Allows company owners and managers to view all received inquiries/surveys, filter by status, reply directly via WhatsApp or Phone call, export CSVs, and update PIN.
- **Multi-page Navigation**: Home, Services Directory, Solar ROI Calculator, CCTV Security, About Us, Why Choose Us, Industries, Contact Us.
- **Interactive Solar ROI Calculator**: Calculate KW system requirement, monthly bill savings in PKR, and K-Electric Net Metering payback.
- **Site Inspection Modal & Quote Generator**: Full custom forms pre-populated with service selections and instant budget estimations.
- **AI Technical Assistant**: Embedded floating AI consultation widget for technical queries.
- **Responsive Dark Theme**: High-contrast, professional luxury aesthetic designed for engineering platforms.
