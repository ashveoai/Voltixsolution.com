import type { IncomingMessage, ServerResponse } from 'http';

interface ExtendedRequest extends IncomingMessage {
  body?: any;
}

const inquiriesList: Array<{
  id: string;
  name: string;
  phone: string;
  email?: string;
  message: string;
  timestamp: string;
}> = [];

export default async function handler(req: ExtendedRequest, res: ServerResponse) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  );

  if (req.method === 'OPTIONS') {
    res.statusCode = 200;
    res.end();
    return;
  }

  if (req.method === 'POST') {
    let body = req.body;

    // Parse body if stream
    if (!body) {
      const buffers = [];
      for await (const chunk of req) {
        buffers.push(chunk);
      }
      const data = Buffer.concat(buffers).toString();
      try {
        body = JSON.parse(data);
      } catch (err) {
        body = {};
      }
    }

    const { name, phone, email, message } = body || {};
    if (!name || !phone || !message) {
      res.statusCode = 400;
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ error: "Name, phone, and message are required." }));
      return;
    }

    const newInquiry = {
      id: "INQ-" + Date.now(),
      name,
      phone,
      email: email || "N/A",
      message,
      timestamp: new Date().toISOString()
    };

    inquiriesList.unshift(newInquiry);

    res.statusCode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({
      success: true,
      message: "Inquiry stored successfully",
      inquiry: newInquiry
    }));
    return;
  }

  if (req.method === 'GET') {
    res.statusCode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({
      total: inquiriesList.length,
      inquiries: inquiriesList
    }));
    return;
  }

  res.statusCode = 405;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify({ error: "Method Not Allowed" }));
}
