import React, { useState } from 'react';
import { Header, PageId } from './components/Header';
import { Hero } from './components/Hero';
import { AboutUs } from './components/AboutUs';
import { ServicesSection } from './components/ServicesSection';
import { CctvHighlight } from './components/CctvHighlight';
import { SolarCalculator } from './components/SolarCalculator';
import { QuoteGenerator } from './components/QuoteGenerator';
import { WhyChooseUs } from './components/WhyChooseUs';
import { IndustriesSection } from './components/IndustriesSection';
import { SiteInspectionModal } from './components/SiteInspectionModal';
import { AiAssistant } from './components/AiAssistant';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ChevronRight, Home, Zap, HardHat, FileText, Phone, Sun, Video, Building2, ShieldCheck } from 'lucide-react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [isInspectionOpen, setIsInspectionOpen] = useState(false);
  const [preselectedService, setPreselectedService] = useState('Electrical Services');
  const [isQuoteOpen, setIsQuoteOpen] = useState(false);

  const handlePageChange = (page: PageId) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenInspectionForService = (serviceName: string) => {
    setPreselectedService(serviceName);
    setIsInspectionOpen(true);
  };

  // Helper for Breadcrumb & Page Banner
  const renderPageHeader = (title: string, subtitle: string, icon: React.ReactNode) => (
    <div className="bg-[#121217] border-b border-[#2A2A32] py-8 px-4">
      <div className="max-w-7xl mx-auto space-y-3">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <button
            onClick={() => handlePageChange('home')}
            className="hover:text-[#C5A267] flex items-center gap-1 transition-colors cursor-pointer"
          >
            <Home className="w-3.5 h-3.5 text-[#C5A267]" />
            <span>Home</span>
          </button>
          <ChevronRight className="w-3 h-3 text-slate-600" />
          <span className="text-white font-semibold">{title}</span>
        </div>

        {/* Page Title */}
        <div className="flex items-center gap-3 pt-1">
          <div className="w-10 h-10 rounded-xl bg-[#C5A267]/20 border border-[#C5A267]/50 flex items-center justify-center text-[#C5A267] shrink-0">
            {icon}
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-white font-serif tracking-tight">
              {title}
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 font-light">
              {subtitle}
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  // Helper for Bottom Switch Page Bar
  const renderBottomNavBanner = () => (
    <div className="bg-[#121217] border-t border-[#2A2A32] py-10 px-4">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="text-xs uppercase tracking-widest text-[#C5A267] font-bold">
            Voltix Solutions Quick Switch
          </div>
          <h3 className="text-xl font-bold text-white font-serif mt-1">
            Looking for something else?
          </h3>
          <p className="text-xs text-slate-400 font-light">
            Navigate through our technical divisions, ROI calculators, or request an engineer site inspection.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => handlePageChange('home')}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-[#181822] hover:bg-[#22222E] text-slate-200 border border-[#2A2A32] cursor-pointer"
          >
            Full Overview Page
          </button>
          <button
            onClick={() => handlePageChange('services')}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-[#181822] hover:bg-[#22222E] text-slate-200 border border-[#2A2A32] cursor-pointer"
          >
            All Services
          </button>
          <button
            onClick={() => handlePageChange('solar')}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-[#181822] hover:bg-[#22222E] text-[#C5A267] border border-[#C5A267]/40 cursor-pointer"
          >
            Solar Calculator
          </button>
          <button
            onClick={() => setIsInspectionOpen(true)}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] cursor-pointer flex items-center gap-1.5 shadow"
          >
            <HardHat className="w-3.5 h-3.5" />
            <span>Book Site Survey</span>
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-slate-100 font-sans selection:bg-[#C5A267] selection:text-[#0A0A0B]">
      
      {/* Header Navigation */}
      <Header
        currentPage={currentPage}
        onPageChange={handlePageChange}
        onOpenInspection={() => setIsInspectionOpen(true)}
        onOpenQuote={() => setIsQuoteOpen(true)}
      />

      <main className="min-h-[70vh]">
        {/* PAGE 1: HOME PAGE (FULL SHOWCASE) */}
        {currentPage === 'home' && (
          <div>
            <Hero
              onOpenInspection={() => setIsInspectionOpen(true)}
              onOpenQuote={() => setIsQuoteOpen(true)}
              onNavigate={handlePageChange}
            />
            <AboutUs />
            <ServicesSection
              onOpenInspectionForService={handleOpenInspectionForService}
              onOpenQuote={() => setIsQuoteOpen(true)}
            />
            <CctvHighlight
              onOpenInspection={() => setIsInspectionOpen(true)}
            />
            <SolarCalculator
              onOpenInspection={() => setIsInspectionOpen(true)}
            />
            <WhyChooseUs />
            <IndustriesSection
              onOpenInspection={() => setIsInspectionOpen(true)}
            />
            <ContactSection />
          </div>
        )}

        {/* PAGE 2: SERVICES DEDICATED PAGE */}
        {currentPage === 'services' && (
          <div>
            {renderPageHeader(
              "Engineering Divisions & Services",
              "Explore turnkey electrical, solar, HVAC, plumbing, fire safety, and CCTV engineering services.",
              <Zap className="w-5 h-5 text-[#C5A267]" />
            )}
            <ServicesSection
              onOpenInspectionForService={handleOpenInspectionForService}
              onOpenQuote={() => setIsQuoteOpen(true)}
            />
            {renderBottomNavBanner()}
          </div>
        )}

        {/* PAGE 3: SOLAR CALCULATOR DEDICATED PAGE */}
        {currentPage === 'solar' && (
          <div>
            {renderPageHeader(
              "Solar ROI & Capacity Calculator",
              "Estimate system size (kW), monthly electricity savings, and K-Electric Green Meter payback period.",
              <Sun className="w-5 h-5 text-[#C5A267]" />
            )}
            <SolarCalculator
              onOpenInspection={() => setIsInspectionOpen(true)}
            />
            {renderBottomNavBanner()}
          </div>
        )}

        {/* PAGE 4: CCTV & SECURITY DEDICATED PAGE */}
        {currentPage === 'cctv' && (
          <div>
            {renderPageHeader(
              "CCTV & Security Surveillance Solutions",
              "High-definition 4K cameras, remote mobile viewing, night vision, biometric access & alarms.",
              <Video className="w-5 h-5 text-[#C5A267]" />
            )}
            <CctvHighlight
              onOpenInspection={() => setIsInspectionOpen(true)}
            />
            {renderBottomNavBanner()}
          </div>
        )}

        {/* PAGE 5: ABOUT US DEDICATED PAGE */}
        {currentPage === 'about' && (
          <div>
            {renderPageHeader(
              "About Voltix Solutions",
              "Pakistan's trusted engineering & technical services partner with certified expertise.",
              <ShieldCheck className="w-5 h-5 text-[#C5A267]" />
            )}
            <AboutUs />
            <WhyChooseUs />
            {renderBottomNavBanner()}
          </div>
        )}

        {/* PAGE 6: WHY CHOOSE US DEDICATED PAGE */}
        {currentPage === 'why-us' && (
          <div>
            {renderPageHeader(
              "Why Choose Voltix Solutions",
              "Our engineering commitment: Quality, transparent composite costing, and 24/7 emergency dispatch.",
              <HardHat className="w-5 h-5 text-[#C5A267]" />
            )}
            <WhyChooseUs />
            {renderBottomNavBanner()}
          </div>
        )}

        {/* PAGE 7: INDUSTRIES DEDICATED PAGE */}
        {currentPage === 'industries' && (
          <div>
            {renderPageHeader(
              "Industries We Serve",
              "Customized engineering solutions for residential, commercial, industrial, and construction sectors.",
              <Building2 className="w-5 h-5 text-[#C5A267]" />
            )}
            <IndustriesSection
              onOpenInspection={() => setIsInspectionOpen(true)}
            />
            {renderBottomNavBanner()}
          </div>
        )}

        {/* PAGE 8: CONTACT US DEDICATED PAGE */}
        {currentPage === 'contact' && (
          <div>
            {renderPageHeader(
              "Contact Us & Head Office",
              "Get in touch with our engineering team in Karachi or book a site visit.",
              <Phone className="w-5 h-5 text-[#C5A267]" />
            )}
            <ContactSection />
            {renderBottomNavBanner()}
          </div>
        )}
      </main>

      {/* Footer */}
      <Footer
        onOpenInspection={() => setIsInspectionOpen(true)}
        onOpenQuote={() => setIsQuoteOpen(true)}
        onNavigate={handlePageChange}
      />

      {/* Modals & AI Assistant Floating Tools */}
      <SiteInspectionModal
        isOpen={isInspectionOpen}
        preselectedService={preselectedService}
        onClose={() => setIsInspectionOpen(false)}
      />

      <QuoteGenerator
        isOpen={isQuoteOpen}
        onClose={() => setIsQuoteOpen(false)}
        onOpenInspection={() => setIsInspectionOpen(true)}
      />

      <AiAssistant />

    </div>
  );
}
