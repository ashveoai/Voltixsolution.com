import { ServiceDetail, Industry, ValueProp } from '../types';

export const COMPANY_INFO = {
  name: "VOLTIX SOLUTIONS",
  legalName: "Voltix Solutions Pvt Ltd",
  tagline: "Powering Innovation. Delivering Excellence.",
  aboutEnglish: "Voltix Solutions is a premier engineering & technical services company offering reliable, end-to-end solutions across residential, commercial, and industrial sectors. We provide a unified platform for Electrical Systems, Solar Energy, HVAC & Cooling, Plumbing, Fire Safety Systems, CCTV Surveillance, General Maintenance, and Technical Engineering Consultations.",
  priorities: [
    "Quality Workmanship",
    "Safe & Compliant Systems",
    "On-Time Project Delivery",
    "Complete Customer Satisfaction"
  ],
  mission: "To deliver cutting-edge technology, safe, and top-quality engineering work, offering cost-effective solutions to our clients built on complete trust and reliability.",
  vision: "To be recognized as Pakistan's leading Engineering & Technical Services Company driven by Innovation, Quality, and Uncompromising Trust.",
  contact: {
    address: "Plot # A-150, Behind Korangi No.6 Market, Opp. Islamia Ground, Karachi, Pakistan",
    phone1: "+92 300 2667840",
    phone1Raw: "923002667840",
    phone2: "+92 304 2510042",
    phone2Raw: "923042510042",
    email: "voltixsolutionpvtpk@gmail.com",
    whatsapp: "923002667840",
    workingHours: "Monday - Saturday: 8:00 AM - 8:00 PM (24/7 Emergency Support)",
    city: "Karachi, Pakistan"
  }
};

export const SERVICES_DATA: ServiceDetail[] = [
  {
    id: "electrical",
    title: "Electrical Services",
    category: "electrical",
    shortDesc: "Comprehensive wiring, power distribution, DB panel installation, cable laying, and generator backup setups for all scales.",
    iconName: "Zap",
    image: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&q=80&w=1000",
    pricingEstimate: "From PKR 25,000 / DB Unit",
    features: [
      "Residential & Commercial Main DB Panels",
      "Industrial High Voltage Cable Laying & Conduits",
      "Circuit Fault Finding & Phase Load Balancing",
      "Generator Synchronization & ATS Panel Setup",
      "UPS & Heavy Power Backup Distribution",
      "Lightning Protection & Earthing Systems"
    ],
    popularFor: ["Industrial Plants", "Commercial Malls", "High-Rise Apartments", "Bungalows"]
  },
  {
    id: "solar",
    title: "Solar Solutions",
    category: "solar",
    shortDesc: "Turnkey On-Grid, Off-Grid, and Hybrid solar energy systems with Net Metering support to reduce electricity bills by up to 85%.",
    iconName: "Sun",
    image: "https://images.unsplash.com/photo-1508873696983-2df515122519?auto=format&fit=crop&q=80&w=1000",
    pricingEstimate: "PKR 165,000 / kW (Turnkey)",
    features: [
      "Tier-1 N-Type Mono PERC Solar Panels (585W+)",
      "High Efficiency On-Grid & Hybrid Inverters",
      "K-Electric Net Metering Green Meter License Processing",
      "Custom Elevated Mounting Structure Fabrication",
      "Battery Storage Banks (Lithium Iron Phosphate)",
      "Solar Cleaning & Preventive Performance Audits"
    ],
    popularFor: ["Rooftop Residential", "Textile & Garment Mills", "Commercial Towers", "Farmhouses"]
  },
  {
    id: "engineering",
    title: "Engineering Consultations",
    category: "engineering",
    shortDesc: "Expert technical project management, load audits, site supervision, MEP design, and industrial plant upkeep.",
    iconName: "HardHat",
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=1000",
    pricingEstimate: "Custom Scope Survey",
    features: [
      "Technical Project Management & Site Surveys",
      "Engineering Power Load & Energy Audits",
      "MEP (Mechanical, Electrical, Plumbing) Drafting",
      "Industrial Plant Upkeep & Machinery Wiring",
      "Compliance, Safety & Thermal Inspection Audits"
    ],
    popularFor: ["Industrial Parks", "Infrastructure Projects", "Commercial Developments"]
  },
  {
    id: "plumbing",
    title: "Plumbing Services",
    category: "plumbing",
    shortDesc: "Flawless water supply systems, drainage networks, underground tank piping, and high-precision leakage detection.",
    iconName: "Wrench",
    image: "https://images.unsplash.com/photo-1505798577917-a65157d3320a?auto=format&fit=crop&q=80&w=1000",
    pricingEstimate: "From PKR 15,000 / Service",
    features: [
      "Water Supply Systems & Booster Pump Installation",
      "Sanitary & Waste Water Drainage Pipe Lines",
      "High-Pressure PPRC & UPVC Pipe Laying",
      "Acoustic Leakage Detection & Pipe Repairs",
      "Underground & Overhead Tank Cleaning & Piping"
    ],
    popularFor: ["Residential Villas", "Hotels & Restaurants", "Hospitals", "Corporate Offices"]
  },
  {
    id: "hvac",
    title: "HVAC & AC Services",
    category: "hvac",
    shortDesc: "Precision air conditioning installation, ductwork fabrication, VRF/VRV central cooling, and chemical servicing.",
    iconName: "Thermometer",
    image: "https://images.unsplash.com/photo-1621905252507-b35492cc74b4?auto=format&fit=crop&q=80&w=1000",
    pricingEstimate: "From PKR 8,500 / AC Unit",
    features: [
      "Split, Inverter & Floor Standing AC Installation",
      "Deep Chemical Servicing & Refrigerant Refilling",
      "HVAC Central Ductwork & VRF System Engineering",
      "Server Room Precision Cooling & Ventilation",
      "Exhaust Ducting & Fresh Air Fan Installation"
    ],
    popularFor: ["Corporate Offices", "Server Rooms", "Shopping Outlets", "Residences"]
  },
  {
    id: "fire-safety",
    title: "Fire Safety Solutions",
    category: "fire-safety",
    shortDesc: "State-of-the-art fire alarms, smoke detectors, fire hydrants, emergency exit lighting, and cylinder refilling.",
    iconName: "Flame",
    image: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?auto=format&fit=crop&q=80&w=1000",
    pricingEstimate: "PKR 45,000 Complete Package",
    features: [
      "Addressable & Conventional Fire Alarm Panels",
      "Optical Smoke & Rate-of-Rise Heat Detectors",
      "Fire Hydrant Ring Mains & Jockey Pump Sets",
      "CO2, Dry Chemical & Foam Extinguisher Supply",
      "Extinguisher Pressure Testing & Refilling Services",
      "Emergency Evacuation Signage & Exit Doors"
    ],
    popularFor: ["Garment Factories", "Warehouses", "High-Rise Plazas", "Schools & Colleges"]
  },
  {
    id: "cctv",
    title: "CCTV & Security Solutions",
    category: "cctv",
    shortDesc: "Advanced HD & IP CCTV cameras, remote smartphone live monitoring, night vision, DVR/NVR, and biometric security.",
    iconName: "Video",
    image: "https://images.unsplash.com/photo-1557597774-9d273605dfa9?auto=format&fit=crop&q=80&w=1000",
    pricingEstimate: "PKR 38,000 (4-Cam HD Setup)",
    features: [
      "4K IP & Full HD Night Vision Security Cameras",
      "DVR / NVR Configuration & Surveillance Hard Drives",
      "Remote Live View via Smartphone (iOS & Android)",
      "Motion Detection, Alarm Sensors & Perimeter Defense",
      "Biometric Access Control & Time Attendance",
      "Long-Distance Fiber & CAT6 Network Cabling"
    ],
    popularFor: ["Warehouses", "Commercial Banks", "Retail Outlets", "Gated Communities"]
  },
  {
    id: "maintenance",
    title: "General Maintenance Services",
    category: "maintenance",
    shortDesc: "360-degree facility upkeep, preventive care, emergency on-call repairs, and Annual Maintenance Contracts (AMC).",
    iconName: "ShieldCheck",
    image: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&q=80&w=1000",
    pricingEstimate: "Annual AMC Contracts Available",
    features: [
      "Comprehensive Facility Maintenance",
      "Electrical & Mechanical Preventive Inspections",
      "Annual Maintenance Contracts (AMC) for Businesses",
      "Emergency Rapid-Dispatch Technical Repair Teams",
      "Structural Patchwork & Facility Repairs"
    ],
    popularFor: ["Corporate Offices", "Property Management Portfolios", "Commercial Centers"]
  }
];

export const WHY_CHOOSE_US: ValueProp[] = [
  {
    id: "team",
    title: "Experienced Engineering Team",
    desc: "Qualified electrical, mechanical, and safety engineers with years of field expertise across Karachi and Pakistan.",
    icon: "Users"
  },
  {
    id: "quality",
    title: "Uncompromising Quality",
    desc: "Strict quality control using certified materials, precision testing equipment, and international standards.",
    icon: "Award"
  },
  {
    id: "pricing",
    title: "Transparent Composite Costing",
    desc: "Clear material and labor breakdowns without hidden surges or unquoted extras.",
    icon: "Calculator"
  },
  {
    id: "delivery",
    title: "On-Time Completion",
    desc: "Disciplined project schedules ensuring zero downtime and exact deadline fulfillment.",
    icon: "Clock"
  },
  {
    id: "support",
    title: "24/7 Emergency Support",
    desc: "Round-the-clock emergency technical hotline and dependable post-installation warranty support.",
    icon: "ShieldCheck"
  },
  {
    id: "solutions",
    title: "Unified Engineering Platform",
    desc: "All electrical, solar, HVAC, plumbing, fire safety, and CCTV requirements managed under one trusted roof.",
    icon: "HardHat"
  }
];

export const INDUSTRIES_SERVED: Industry[] = [
  {
    id: "residential",
    name: "Residential Projects",
    desc: "Villas, bungalows, apartments, housing societies, and luxury farmhouses.",
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1000",
    icon: "Building2"
  },
  {
    id: "commercial",
    name: "Commercial Buildings",
    desc: "Shopping plazas, corporate towers, hotel complexes, and multi-tenant centers.",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1000",
    icon: "Building"
  },
  {
    id: "industrial",
    name: "Factories & Industries",
    desc: "Textile mills, manufacturing plants, pharmaceuticals, and processing units.",
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=1000",
    icon: "Factory"
  },
  {
    id: "offices",
    name: "Offices & Corporate Hubs",
    desc: "Modern office interiors, IT hubs, call centers, and administrative branches.",
    image: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1000",
    icon: "Briefcase"
  },
  {
    id: "retail",
    name: "Retail Outlets & Supermarkets",
    desc: "Flagship retail stores, supermarkets, restaurants, and boutique outlets.",
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=1000",
    icon: "ShoppingBag"
  },
  {
    id: "construction",
    name: "Construction Developments",
    desc: "New building developments, site infrastructure, foundation electrification, and piping.",
    image: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&q=80&w=1000",
    icon: "HardHat"
  }
];

export const TESTIMONIALS = [
  {
    name: "Engr. Tariq Mehmood",
    role: "Facility Director, SITE Industrial Area Mill",
    comment: "Voltix Solutions overhauled our factory's primary DB panels and fire safety system. Their team worked round the clock during our scheduled maintenance shutdown without disrupting production.",
    rating: 5,
    location: "Karachi Industrial Area"
  },
  {
    name: "Farhan Saeed",
    role: "Commercial Plaza Owner",
    comment: "Installed a 50kW Hybrid Solar System with net metering support. Electricity bills dropped by over 75%! Highly professional team and transparent composite pricing.",
    rating: 5,
    location: "Korangi, Karachi"
  },
  {
    name: "Dr. Ayesha Alvi",
    role: "Resident",
    comment: "Flawless HVAC installation and complete CCTV security setup for our new house in DHA. Their response speed and clean cable work are unmatched in Karachi.",
    rating: 5,
    location: "DHA Phase 6, Karachi"
  }
];

