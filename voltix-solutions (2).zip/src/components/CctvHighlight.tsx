import React from 'react';
import { Video, Smartphone, Eye, Server, CheckSquare, HardHat, PhoneCall } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';

interface CctvHighlightProps {
  onOpenInspection: () => void;
}

export const CctvHighlight: React.FC<CctvHighlightProps> = ({ onOpenInspection }) => {
  const cctvFeatures = [
    "HD & IP CCTV Camera Installation",
    "Indoor & Outdoor Surveillance Systems",
    "Night Vision & Motion Detection Cameras",
    "DVR / NVR Setup & Hard Drive Configuration",
    "Remote Mobile Live Monitoring Systems",
    "Office, Factory & Warehouse Security Solutions",
    "Video Recording & Cloud/Local Backup Systems",
    "Maintenance & Troubleshooting Services",
    "Access Control & Biometric Security Integration"
  ];

  const whyChooseCctv = [
    "Professional Installation by Certified Engineers",
    "High-Quality & Weatherproof Security Equipment",
    "Reliable 24/7 Monitoring Solutions",
    "Affordable & Customized Packages for Every Budget",
    "Dedicated Technical Support & Maintenance",
    "Secure & Smart Surveillance Systems with App Access"
  ];

  return (
    <section className="py-16 bg-[#0A0A0B] text-slate-100 relative border-b border-[#2A2A32]">
      <div className="max-w-7xl mx-auto px-4">
        
        <div className="grid lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Text & Specs */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 bg-[#121217] border border-[#C5A267]/40 text-[#C5A267] text-xs font-bold uppercase px-3.5 py-1 rounded-full">
              <Video className="w-4 h-4 text-[#C5A267]" />
              <span>Specialized Security & Surveillance Division</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-black text-white font-serif">
              CCTV SURVEILLANCE & <br />
              <span className="text-[#C5A267]">
                INTEGRATED SECURITY SOLUTIONS
              </span>
            </h2>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed font-light">
              We provide advanced CCTV Surveillance & Security Solutions for homes, corporate offices, industrial plants, warehouses, commercial plazas, and retail chains across Karachi. Our expert engineering team delivers complete security systems with professional installation, remote smartphone configuration, and preventive maintenance.
            </p>

            {/* Checklist of CCTV Services */}
            <div className="grid sm:grid-cols-2 gap-2.5 pt-2">
              {cctvFeatures.map((item, idx) => (
                <div key={idx} className="bg-[#121217] border border-[#2A2A32] p-3 rounded-xl flex items-start gap-2.5 hover:border-[#C5A267]/50 transition-all">
                  <Eye className="w-4 h-4 text-[#38BDF8] shrink-0 mt-0.5" />
                  <span className="text-xs text-slate-200 font-medium">{item}</span>
                </div>
              ))}
            </div>

            {/* Why Choose Voltix Security */}
            <div className="bg-[#121217] border border-[#C5A267]/50 rounded-2xl p-5 space-y-3">
              <h3 className="text-xs font-bold text-[#C5A267] uppercase tracking-wider flex items-center gap-2">
                <CheckSquare className="w-4 h-4" />
                <span>Why Choose Voltix CCTV Solutions?</span>
              </h3>
              <div className="grid sm:grid-cols-2 gap-2 text-xs text-slate-300">
                {whyChooseCctv.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="text-[#C5A267] font-bold">✓</span>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onOpenInspection}
                className="bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] font-extrabold px-6 py-3 rounded-xl shadow-lg transition-all text-xs cursor-pointer flex items-center gap-2"
              >
                <HardHat className="w-4 h-4" />
                <span>Book Free Security Audit</span>
              </button>
              <a
                href={`tel:${COMPANY_INFO.contact.phone1Raw}`}
                className="inline-flex items-center gap-2 text-slate-300 hover:text-white text-xs font-semibold font-mono"
              >
                <PhoneCall className="w-4 h-4 text-[#38BDF8]" />
                <span>Security Hotline: {COMPANY_INFO.contact.phone1}</span>
              </a>
            </div>
          </div>

          {/* Right Image Banner */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#C5A267]/50 shadow-2xl bg-[#121217]">
              <img
                src="https://images.unsplash.com/photo-1557597774-9d273605dfa9?auto=format&fit=crop&q=80&w=1000"
                alt="Voltix CCTV Surveillance Systems"
                className="w-full h-96 object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B] via-transparent to-transparent opacity-80" />
              
              {/* Feature Highlights Overlay */}
              <div className="absolute bottom-6 left-6 right-6 space-y-2">
                <div className="bg-[#0A0A0B]/90 border border-[#C5A267]/50 p-3 rounded-xl backdrop-blur flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                    <span className="font-semibold text-white">Live Mobile Viewing</span>
                  </div>
                  <span className="text-emerald-400 font-bold">iOS & Android</span>
                </div>

                <div className="bg-[#0A0A0B]/90 border border-[#38BDF8]/50 p-3 rounded-xl backdrop-blur flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <Server className="w-4 h-4 text-[#38BDF8]" />
                    <span className="font-semibold text-white">4K NVR & Night Vision</span>
                  </div>
                  <span className="text-[#38BDF8] font-bold">24/7 Recording</span>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};

