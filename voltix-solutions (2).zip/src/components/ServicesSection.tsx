import React, { useState } from 'react';
import { 
  Zap, 
  Sun, 
  HardHat, 
  Wrench, 
  Thermometer, 
  Flame, 
  Video, 
  ShieldCheck, 
  CheckCircle2, 
  X, 
  FileText,
  ChevronRight,
  Tag
} from 'lucide-react';
import { SERVICES_DATA, COMPANY_INFO } from '../data/companyData';
import { ServiceDetail } from '../types';

interface ServicesSectionProps {
  onOpenInspectionForService: (serviceName: string) => void;
  onOpenQuote: () => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onOpenInspectionForService,
  onOpenQuote
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeModalService, setActiveModalService] = useState<ServiceDetail | null>(null);

  const filterCategories = [
    { id: 'all', label: 'All Services', icon: ShieldCheck },
    { id: 'electrical', label: 'Electrical', icon: Zap },
    { id: 'solar', label: 'Solar Solutions', icon: Sun },
    { id: 'engineering', label: 'Engineering', icon: HardHat },
    { id: 'plumbing', label: 'Plumbing', icon: Wrench },
    { id: 'hvac', label: 'HVAC / AC', icon: Thermometer },
    { id: 'fire-safety', label: 'Fire Safety', icon: Flame },
    { id: 'cctv', label: 'CCTV Security', icon: Video },
    { id: 'maintenance', label: 'Maintenance', icon: ShieldCheck },
  ];

  const filteredServices = selectedCategory === 'all'
    ? SERVICES_DATA
    : SERVICES_DATA.filter(s => s.category === selectedCategory);

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Zap': return <Zap className="w-4 h-4 text-[#C5A267]" />;
      case 'Sun': return <Sun className="w-4 h-4 text-amber-400" />;
      case 'HardHat': return <HardHat className="w-4 h-4 text-[#38BDF8]" />;
      case 'Wrench': return <Wrench className="w-4 h-4 text-emerald-400" />;
      case 'Thermometer': return <Thermometer className="w-4 h-4 text-cyan-400" />;
      case 'Flame': return <Flame className="w-4 h-4 text-rose-400" />;
      case 'Video': return <Video className="w-4 h-4 text-blue-400" />;
      default: return <ShieldCheck className="w-4 h-4 text-[#C5A267]" />;
    }
  };

  return (
    <section className="py-16 md:py-24 bg-[#0A0A0B] text-slate-100 relative">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Header Title */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 bg-[#121217] border border-[#C5A267]/40 text-[#C5A267] text-xs uppercase font-bold px-3.5 py-1 rounded-full">
            <Zap className="w-3.5 h-3.5 fill-[#C5A267]" />
            <span>Turnkey Engineering & MEP Solutions</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white font-serif">
            OUR <span className="text-[#C5A267]">ENGINEERING DIVISIONS</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base font-light">
            Voltix Solutions provides turn-key design, procurement, certified installation, and annual maintenance contracts across 8 specialized divisions.
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-[#C5A267] to-[#38BDF8] mx-auto rounded-full" />
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {filterCategories.map(cat => {
            const Icon = cat.icon;
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#C5A267] text-[#0A0A0B] shadow-lg font-bold scale-105'
                    : 'bg-[#121217] hover:bg-[#181822] text-slate-300 border border-[#2A2A32]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#0A0A0B]' : 'text-[#C5A267]'}`} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredServices.map(service => (
            <div
              key={service.id}
              className="bg-[#121217] border border-[#2A2A32] hover:border-[#C5A267]/70 rounded-2xl overflow-hidden shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between group"
            >
              <div>
                {/* Service Image Banner */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      // Fallback image if network fails
                      e.currentTarget.src = "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=1000";
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#121217] via-transparent to-transparent opacity-90" />
                  
                  {/* Category Pill Overlay */}
                  <div className="absolute top-3 left-3 bg-[#0A0A0B]/90 border border-[#C5A267]/40 text-[#C5A267] text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md backdrop-blur flex items-center gap-1">
                    {getIcon(service.iconName)}
                    <span>{service.category.toUpperCase()}</span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-3">
                  <h3 className="text-lg font-bold text-white font-serif group-hover:text-[#C5A267] transition-colors flex items-center justify-between">
                    <span>{service.title}</span>
                  </h3>

                  <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                    {service.shortDesc}
                  </p>

                  {/* Professional Price Indicator */}
                  {service.pricingEstimate && (
                    <div className="bg-[#181822] border border-[#2A2A32] rounded-lg p-2.5 flex items-center gap-2">
                      <Tag className="w-3.5 h-3.5 text-[#C5A267] shrink-0" />
                      <div>
                        <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">Standard Turnkey Rate</div>
                        <div className="text-xs font-bold text-[#38BDF8] font-mono">{service.pricingEstimate}</div>
                      </div>
                    </div>
                  )}

                  {/* Top 3 Features Checklist */}
                  <div className="pt-2 border-t border-[#1E1E24] space-y-1.5">
                    {service.features.slice(0, 3).map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span className="line-clamp-1">{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="p-5 pt-0 mt-auto flex items-center gap-2">
                <button
                  onClick={() => setActiveModalService(service)}
                  className="w-full bg-[#181822] hover:bg-[#22222E] border border-[#2A2A32] text-slate-200 text-xs font-bold py-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <FileText className="w-3.5 h-3.5 text-[#C5A267]" />
                  <span>Full Scope Details</span>
                </button>
                <button
                  onClick={() => onOpenInspectionForService(service.title)}
                  className="bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] p-2.5 rounded-xl transition-all cursor-pointer shrink-0"
                  title="Book Technical Survey"
                >
                  <ChevronRight className="w-4 h-4 font-bold" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Full Technical Scope Detail Modal */}
      {activeModalService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#0A0A0B] border border-[#C5A267] w-full max-w-2xl rounded-2xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col text-slate-100">
            
            {/* Modal Header */}
            <div className="relative h-52 overflow-hidden shrink-0">
              <img
                src={activeModalService.image}
                alt={activeModalService.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B] via-[#0A0A0B]/70 to-transparent" />
              
              <button
                onClick={() => setActiveModalService(null)}
                className="absolute top-4 right-4 bg-[#121217]/80 hover:bg-rose-600 text-white p-2 rounded-full transition-all cursor-pointer border border-white/20"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute bottom-4 left-6 right-6">
                <div className="inline-flex items-center gap-1.5 bg-[#C5A267] text-[#0A0A0B] text-xs font-bold px-2.5 py-0.5 rounded uppercase mb-1">
                  {activeModalService.category.toUpperCase()} DIVISION
                </div>
                <h3 className="text-2xl font-black text-white font-serif">
                  {activeModalService.title}
                </h3>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-6">
              <div>
                <h4 className="text-xs uppercase tracking-wider font-bold text-[#38BDF8] mb-1">
                  Service Overview
                </h4>
                <p className="text-slate-300 text-sm leading-relaxed">
                  {activeModalService.shortDesc}
                </p>
              </div>

              {activeModalService.pricingEstimate && (
                <div className="bg-[#121217] border border-[#2A2A32] p-4 rounded-xl flex items-center gap-3">
                  <Tag className="w-5 h-5 text-[#C5A267]" />
                  <div>
                    <div className="text-xs text-slate-400 font-semibold">Estimated Package Pricing</div>
                    <div className="text-sm font-bold text-[#38BDF8] font-mono">{activeModalService.pricingEstimate}</div>
                  </div>
                </div>
              )}

              <div>
                <h4 className="text-xs uppercase tracking-wider font-bold text-[#C5A267] mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#C5A267]" />
                  <span>Technical Specifications & Scope of Work</span>
                </h4>
                <div className="grid sm:grid-cols-2 gap-2.5">
                  {activeModalService.features.map((feat, idx) => (
                    <div key={idx} className="bg-[#121217] border border-[#2A2A32] p-3 rounded-lg text-xs text-slate-200 flex items-start gap-2">
                      <span className="text-[#C5A267] font-bold">•</span>
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-xs uppercase tracking-wider font-bold text-slate-400 mb-2">
                  Key Target Sectors:
                </h4>
                <div className="flex flex-wrap gap-2">
                  {activeModalService.popularFor.map((sec, idx) => (
                    <span key={idx} className="bg-[#181822] text-slate-300 text-xs px-2.5 py-1 rounded-md border border-[#2A2A32]">
                      {sec}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-[#121217] border-t border-[#2A2A32] flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
              <div className="text-xs text-slate-400">
                Direct Engineering Hotline: <strong className="text-white font-mono">{COMPANY_INFO.contact.phone1}</strong>
              </div>
              <button
                onClick={() => {
                  const svcTitle = activeModalService.title;
                  setActiveModalService(null);
                  onOpenInspectionForService(svcTitle);
                }}
                className="w-full sm:w-auto bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] font-extrabold px-5 py-2.5 rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow"
              >
                <HardHat className="w-4 h-4" />
                <span>Book Free Technical Survey</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};

