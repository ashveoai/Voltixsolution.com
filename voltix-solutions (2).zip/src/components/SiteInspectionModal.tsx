import React, { useState } from 'react';
import { HardHat, Calendar, Clock, MapPin, Phone, User, CheckCircle2, X, MessageSquare, AlertTriangle } from 'lucide-react';
import { COMPANY_INFO, SERVICES_DATA } from '../data/companyData';

interface SiteInspectionModalProps {
  isOpen: boolean;
  preselectedService?: string;
  onClose: () => void;
}

export const SiteInspectionModal: React.FC<SiteInspectionModalProps> = ({
  isOpen,
  preselectedService = 'Electrical Services',
  onClose
}) => {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [serviceType, setServiceType] = useState(preselectedService);
  const [propertyType, setPropertyType] = useState('Residential House');
  const [preferredDate, setPreferredDate] = useState('');
  const [preferredTime, setPreferredTime] = useState('Morning (9 AM - 1 PM)');
  const [urgency, setUrgency] = useState<'routine' | 'urgent' | 'emergency'>('routine');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const record = {
      id: 'VOLTIX-SURVEY-' + Math.floor(100000 + Math.random() * 900000),
      name: fullName,
      phone,
      email: 'N/A',
      message: `SITE SURVEY: ${serviceType} | Address: ${address} | Schedule: ${preferredDate} (${preferredTime}) | Urgency: ${urgency.toUpperCase()} | Notes: ${notes || 'None'}`,
      timestamp: new Date().toLocaleString()
    };

    try {
      const existing = JSON.parse(localStorage.getItem('voltix_inquiries') || '[]');
      existing.unshift(record);
      localStorage.setItem('voltix_inquiries', JSON.stringify(existing));
    } catch (err) {
      console.error("Localstorage save error", err);
    }

    try {
      await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: fullName,
          phone,
          message: record.message
        })
      });
    } catch (err) {
      console.error("API submit error", err);
    }

    setSubmitted(true);
  };

  const sendWhatsAppBooking = () => {
    const text = `VOLTIX SOLUTIONS - TECHNICAL SITE INSPECTION REQUEST
Client Name: ${fullName}
Phone: ${phone}
Address: ${address}
Urgency: ${urgency.toUpperCase()}
Requested Service: ${serviceType}
Property: ${propertyType}
Preferred Date/Time: ${preferredDate} (${preferredTime})
Notes: ${notes || 'None'}`;

    window.open(`https://wa.me/${COMPANY_INFO.contact.whatsapp}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#121217] border border-[#C5A267] w-full max-w-2xl rounded-2xl overflow-hidden shadow-2xl max-h-[92vh] flex flex-col text-white">
        
        {/* Header */}
        <div className="bg-[#0A0A0B] p-5 border-b border-[#2A2A32] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#C5A267]/20 border border-[#C5A267] flex items-center justify-center text-[#C5A267]">
              <HardHat className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white font-serif">
                Book On-Site Technical Survey
              </h3>
              <p className="text-xs text-[#38BDF8]">
                Certified Engineer Site Inspection in Karachi
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              setSubmitted(false);
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-white hover:bg-rose-600 rounded-lg transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        {submitted ? (
          <div className="p-8 text-center space-y-5 my-auto">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-500 flex items-center justify-center text-emerald-400 mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            
            <h4 className="text-2xl font-bold text-white font-serif">
              Survey Booking Request Received!
            </h4>
            <p className="text-sm text-slate-300 max-w-md mx-auto">
              Thank you, <strong className="text-white">{fullName}</strong>. Our senior engineering team will contact you at <strong className="text-[#C5A267] font-mono">{phone}</strong> shortly to confirm your site visit address.
            </p>

            <div className="bg-[#0A0A0B] p-4 rounded-xl text-xs text-slate-300 border border-[#2A2A32] max-w-md mx-auto text-left space-y-1">
              <div><strong>Service Requested:</strong> {serviceType}</div>
              <div><strong>Address:</strong> {address}</div>
              <div><strong>Preferred Schedule:</strong> {preferredDate} ({preferredTime})</div>
            </div>

            <div className="pt-3 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={sendWhatsAppBooking}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2.5 rounded-xl text-xs flex items-center gap-2 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Confirm Instantly on WhatsApp</span>
              </button>

              <button
                onClick={() => {
                  setSubmitted(false);
                  onClose();
                }}
                className="bg-[#181822] hover:bg-[#22222E] text-white font-semibold px-5 py-2.5 rounded-xl text-xs border border-[#2A2A32] cursor-pointer"
              >
                Close Window
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4">
            
            {/* Urgency Selector */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-300 font-medium">Dispatch Priority:</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setUrgency('routine')}
                  className={`p-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                    urgency === 'routine'
                      ? 'bg-[#181822] text-white border-[#C5A267]'
                      : 'bg-[#0A0A0B] text-slate-400 border-[#2A2A32]'
                  }`}
                >
                  Standard Survey
                </button>
                <button
                  type="button"
                  onClick={() => setUrgency('urgent')}
                  className={`p-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                    urgency === 'urgent'
                      ? 'bg-amber-600/30 text-amber-300 border-amber-500'
                      : 'bg-[#0A0A0B] text-slate-400 border-[#2A2A32]'
                  }`}
                >
                  Urgent (24 Hours)
                </button>
                <button
                  type="button"
                  onClick={() => setUrgency('emergency')}
                  className={`p-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer flex items-center justify-center gap-1 ${
                    urgency === 'emergency'
                      ? 'bg-rose-600 text-white border-rose-500 animate-pulse'
                      : 'bg-[#0A0A0B] text-slate-400 border-[#2A2A32]'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Emergency Fault</span>
                </button>
              </div>
            </div>

            {/* Inputs Grid */}
            <div className="grid sm:grid-cols-2 gap-4">
              
              <div className="space-y-1">
                <label className="text-xs text-slate-300 flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-[#C5A267]" />
                  <span>Full Name *</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Muhammad Farhan"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-300 flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span>Phone Number *</span>
                </label>
                <input
                  type="tel"
                  required
                  placeholder="0300 1234567"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-300 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-rose-400" />
                  <span>Property Address / Area *</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Plot A-12, Korangi Industrial Area, Karachi"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-300">Service Required:</label>
                <select
                  value={serviceType}
                  onChange={(e) => setServiceType(e.target.value)}
                  className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
                >
                  {SERVICES_DATA.map(s => (
                    <option key={s.id} value={s.title}>{s.title}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-300 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Preferred Date:</span>
                </label>
                <input
                  type="date"
                  value={preferredDate}
                  onChange={(e) => setPreferredDate(e.target.value)}
                  className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-300 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Preferred Time Slot:</span>
                </label>
                <select
                  value={preferredTime}
                  onChange={(e) => setPreferredTime(e.target.value)}
                  className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
                >
                  <option>Morning (9 AM - 1 PM)</option>
                  <option>Afternoon (1 PM - 5 PM)</option>
                  <option>Evening (5 PM - 8 PM)</option>
                </select>
              </div>

            </div>

            <div className="space-y-1">
              <label className="text-xs text-slate-300">Fault / Requirement Description:</label>
              <textarea
                rows={2}
                placeholder="Describe any existing fault, load requirements, or site specifications..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
              />
            </div>

            <div className="p-3 bg-[#0A0A0B] border border-[#2A2A32] rounded-xl text-[11px] text-slate-300 flex items-center justify-between font-mono">
              <span>Karachi Engineering HQ:</span>
              <strong className="text-[#C5A267]">{COMPANY_INFO.contact.phone1}</strong>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="bg-[#181822] hover:bg-[#22222E] text-white px-4 py-2.5 rounded-xl text-xs border border-[#2A2A32] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] font-extrabold px-6 py-2.5 rounded-xl text-xs shadow-lg flex items-center gap-1.5 cursor-pointer"
              >
                <HardHat className="w-4 h-4" />
                <span>Confirm Survey Request</span>
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};

