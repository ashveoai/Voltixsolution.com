import React from 'react';
import { Users, Award, Calculator, Clock, ShieldCheck, HardHat } from 'lucide-react';
import { WHY_CHOOSE_US } from '../data/companyData';

export const WhyChooseUs: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Users': return <Users className="w-6 h-6 text-[#C5A267]" />;
      case 'Award': return <Award className="w-6 h-6 text-[#38BDF8]" />;
      case 'Calculator': return <Calculator className="w-6 h-6 text-emerald-400" />;
      case 'Clock': return <Clock className="w-6 h-6 text-cyan-400" />;
      case 'ShieldCheck': return <ShieldCheck className="w-6 h-6 text-[#C5A267]" />;
      default: return <HardHat className="w-6 h-6 text-[#C5A267]" />;
    }
  };

  return (
    <section className="py-16 md:py-24 bg-[#0A0A0B] text-slate-100 relative border-b border-[#2A2A32]">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 bg-[#121217] border border-[#C5A267]/40 text-[#C5A267] text-xs uppercase font-bold px-3.5 py-1 rounded-full">
            <Award className="w-3.5 h-3.5" />
            <span>Competitive Differentiation & Corporate Integrity</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white font-serif">
            WHY CHOOSE <span className="text-[#C5A267]">VOLTIX SOLUTIONS</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base font-light">
            We combine certified engineering experience with transparent composite pricing and uncompromised safety standards.
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-[#C5A267] to-[#38BDF8] mx-auto rounded-full" />
        </div>

        {/* 6 Value Prop Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {WHY_CHOOSE_US.map((item) => (
            <div
              key={item.id}
              className="bg-[#121217] border border-[#2A2A32] hover:border-[#C5A267]/60 p-6 rounded-2xl shadow-xl transition-all duration-300 hover:-translate-y-1 space-y-3 group"
            >
              <div className="w-12 h-12 rounded-xl bg-[#181822] border border-[#2A2A32] flex items-center justify-center group-hover:border-[#C5A267] transition-colors">
                {getIcon(item.icon)}
              </div>

              <div>
                <h3 className="text-lg font-bold text-white font-serif group-hover:text-[#C5A267] transition-colors">
                  {item.title}
                </h3>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed font-light">
                {item.desc}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

