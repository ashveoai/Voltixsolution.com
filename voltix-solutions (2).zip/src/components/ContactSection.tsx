import React, { useState } from 'react';
import { MapPin, Phone, Mail, Send, MessageSquare, Download, CheckCircle2, Lock, ShieldCheck } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';
import { OwnerAdminPortal } from './OwnerAdminPortal';

export const ContactSection: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);
  const [lastReceiptId, setLastReceiptId] = useState('');
  const [showOwnerPortal, setShowOwnerPortal] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const receiptId = 'VOLTIX-' + Math.floor(100000 + Math.random() * 900000);
    const newInquiry = {
      id: receiptId,
      name,
      phone,
      email: email || 'N/A',
      message,
      timestamp: new Date().toLocaleString()
    };

    setLastReceiptId(receiptId);

    // Save locally for instant backup
    try {
      const existing = JSON.parse(localStorage.getItem('voltix_inquiries') || '[]');
      existing.unshift(newInquiry);
      localStorage.setItem('voltix_inquiries', JSON.stringify(existing));
    } catch (err) {
      console.error("Localstorage save error", err);
    }

    // Send to server API endpoint
    try {
      await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, phone, email, message })
      });
    } catch (err) {
      console.error("API submit error", err);
    }

    setSent(true);
  };

  const downloadVCard = () => {
    const vcard = `BEGIN:VCARD
VERSION:3.0
FN:Voltix Solutions
ORG:Voltix Solutions Pvt Ltd
TITLE:Engineering & Technical Services
TEL;TYPE=WORK,VOICE:${COMPANY_INFO.contact.phone1}
TEL;TYPE=CELL:${COMPANY_INFO.contact.phone2}
EMAIL:${COMPANY_INFO.contact.email}
ADR;TYPE=WORK:;;Plot A-150 Behind Korangi No.6 Market Opp Islamia Ground;Karachi;;Pakistan
URL:https://voltixsolutions.pk
END:VCARD`;

    const blob = new Blob([vcard], { type: 'text/vcard' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Voltix_Solutions_Contact.vcf';
    a.click();
  };

  return (
    <section className="py-16 md:py-24 bg-[#0A0A0B] text-slate-100 relative border-b border-[#2A2A32]">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 bg-[#121217] border border-[#C5A267]/40 text-[#C5A267] text-xs uppercase font-bold px-3.5 py-1 rounded-full">
            <MapPin className="w-3.5 h-3.5 text-rose-400" />
            <span>Connect With Our Corporate Team</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white font-serif">
            GET IN TOUCH WITH <span className="text-[#C5A267]">VOLTIX SOLUTIONS</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base font-light">
            Visit our Karachi engineering head office or reach out for immediate project consultations, technical quotes, or emergency site visits.
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-[#C5A267] to-[#38BDF8] mx-auto rounded-full" />
        </div>

        <div className="grid lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Contact Cards & QR */}
          <div className="lg:col-span-6 space-y-6">
            
            {/* Address & Direct Phone Box */}
            <div className="bg-[#121217] border border-[#2A2A32] rounded-2xl p-6 shadow-xl space-y-5">
              
              {/* Address */}
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#181822] border border-[#2A2A32] flex items-center justify-center text-rose-400 shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Head Office Location
                  </h3>
                  <p className="text-sm font-semibold text-white mt-1 leading-relaxed">
                    {COMPANY_INFO.contact.address}
                  </p>
                  <a
                    href="https://maps.google.com/?q=Korangi+No+6+Karachi"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-[#38BDF8] hover:underline mt-1 font-medium"
                  >
                    <span>View on Google Maps</span>
                  </a>
                </div>
              </div>

              {/* Phones */}
              <div className="flex items-start gap-4 pt-4 border-t border-[#2A2A32]">
                <div className="w-12 h-12 rounded-xl bg-[#181822] border border-[#2A2A32] flex items-center justify-center text-[#38BDF8] shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Direct Contact Lines
                  </h3>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3 mt-1 font-mono">
                    <a
                      href={`tel:${COMPANY_INFO.contact.phone1Raw}`}
                      className="text-base font-bold text-[#C5A267] hover:underline"
                    >
                      {COMPANY_INFO.contact.phone1}
                    </a>
                    <span className="hidden sm:inline text-slate-600">•</span>
                    <a
                      href={`tel:${COMPANY_INFO.contact.phone2Raw}`}
                      className="text-base font-bold text-[#C5A267] hover:underline"
                    >
                      {COMPANY_INFO.contact.phone2}
                    </a>
                  </div>
                </div>
              </div>

              {/* Email */}
              <div className="flex items-start gap-4 pt-4 border-t border-[#2A2A32]">
                <div className="w-12 h-12 rounded-xl bg-[#181822] border border-[#2A2A32] flex items-center justify-center text-[#C5A267] shrink-0">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Official Corporate Email
                  </h3>
                  <a
                    href={`mailto:${COMPANY_INFO.contact.email}`}
                    className="text-sm font-semibold text-white hover:text-[#C5A267] transition-colors mt-1 block font-mono"
                  >
                    {COMPANY_INFO.contact.email}
                  </a>
                </div>
              </div>

            </div>

            {/* QR Code & Business Card Card */}
            <div className="bg-[#121217] border border-[#2A2A32] rounded-2xl p-6 shadow-xl flex flex-col sm:flex-row items-center gap-6">
              
              {/* QR Graphic */}
              <div className="bg-white p-3 rounded-xl border-2 border-[#C5A267] shadow-md shrink-0">
                <svg
                  className="w-28 h-28"
                  viewBox="0 0 100 100"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <rect width="100" height="100" fill="white" />
                  <rect x="5" y="5" width="28" height="28" fill="#0A0A0B" />
                  <rect x="9" y="9" width="20" height="20" fill="white" />
                  <rect x="13" y="13" width="12" height="12" fill="#0A0A0B" />

                  <rect x="67" y="5" width="28" height="28" fill="#0A0A0B" />
                  <rect x="71" y="9" width="20" height="20" fill="white" />
                  <rect x="75" y="13" width="12" height="12" fill="#0A0A0B" />

                  <rect x="5" y="67" width="28" height="28" fill="#0A0A0B" />
                  <rect x="9" y="71" width="20" height="20" fill="white" />
                  <rect x="13" y="75" width="12" height="12" fill="#0A0A0B" />

                  <rect x="40" y="10" width="8" height="15" fill="#38BDF8" />
                  <rect x="52" y="10" width="10" height="8" fill="#0A0A0B" />
                  <rect x="40" y="30" width="20" height="8" fill="#0A0A0B" />
                  <rect x="10" y="40" width="15" height="8" fill="#0A0A0B" />
                  <rect x="30" y="45" width="12" height="12" fill="#C5A267" />
                  <rect x="50" y="45" width="18" height="8" fill="#0A0A0B" />
                  <rect x="75" y="40" width="15" height="15" fill="#0A0A0B" />
                  <rect x="40" y="65" width="10" height="25" fill="#0A0A0B" />
                  <rect x="55" y="65" width="15" height="10" fill="#38BDF8" />
                  <rect x="75" y="75" width="15" height="15" fill="#C5A267" />
                </svg>
              </div>

              <div className="space-y-3 text-center sm:text-left">
                <div>
                  <h4 className="text-base font-bold text-white font-serif">
                    Save Digital Contact Card
                  </h4>
                  <p className="text-xs text-slate-400 font-light">
                    Scan or click below to save Voltix Solutions phone numbers directly to your mobile address book.
                  </p>
                </div>

                <button
                  onClick={downloadVCard}
                  className="bg-[#181822] hover:bg-[#22222E] border border-[#C5A267]/40 text-white font-semibold px-4 py-2 rounded-xl text-xs flex items-center gap-2 mx-auto sm:mx-0 cursor-pointer shadow transition-all"
                >
                  <Download className="w-4 h-4 text-[#C5A267]" />
                  <span>Download vCard Contact</span>
                </button>
              </div>

            </div>

          </div>

          {/* Right Direct Message Form */}
          <div className="lg:col-span-6 bg-[#121217] border border-[#2A2A32] rounded-2xl p-6 md:p-8 shadow-xl space-y-5">
            
            <div className="border-b border-[#2A2A32] pb-4">
              <h3 className="text-xl font-bold text-white font-serif">
                Send Direct Inquiry
              </h3>
              <p className="text-xs text-slate-400">
                Inquire about electrical, solar, fire safety, HVAC, CCTV, or maintenance solutions.
              </p>
            </div>

            {sent ? (
              <div className="py-8 px-4 text-center space-y-4 bg-[#0A0A0B] rounded-xl border border-emerald-500/40">
                <div className="w-14 h-14 rounded-full bg-emerald-500/20 border-2 border-emerald-500 flex items-center justify-center text-emerald-400 mx-auto shadow-lg">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                
                <div>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-mono px-2.5 py-0.5 rounded uppercase font-bold border border-emerald-500/30">
                    Inquiry Reference: #{lastReceiptId}
                  </span>
                  <h4 className="text-xl font-bold text-white font-serif mt-2">
                    Inquiry Successfully Logged!
                  </h4>
                  <p className="text-xs text-slate-300 max-w-sm mx-auto mt-1">
                    Thank you <strong className="text-white">{name}</strong>. Your message has been submitted to Voltix Solutions Engineering Dispatch.
                  </p>
                </div>

                <div className="bg-[#121217] p-4 rounded-xl border border-[#2A2A32] text-left text-xs space-y-1 max-w-sm mx-auto">
                  <div className="text-slate-400"><strong>Name:</strong> {name}</div>
                  <div className="text-slate-400"><strong>Phone:</strong> {phone}</div>
                  <div className="text-slate-300 pt-1 border-t border-[#181822] mt-1">
                    "{message}"
                  </div>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                  <a
                    href={`https://wa.me/${COMPANY_INFO.contact.whatsapp}?text=${encodeURIComponent(
                      `VOLTIX INQUIRY [Ref #${lastReceiptId}]\nName: ${name}\nPhone: ${phone}\nMessage: ${message}`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 shadow cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Send Directly via WhatsApp</span>
                  </a>

                  <button
                    onClick={() => {
                      setSent(false);
                      setName('');
                      setPhone('');
                      setEmail('');
                      setMessage('');
                    }}
                    className="w-full sm:w-auto bg-[#181822] hover:bg-[#22222E] text-slate-300 px-4 py-2.5 rounded-xl text-xs font-semibold cursor-pointer border border-[#2A2A32]"
                  >
                    Submit New Query
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                
                <div className="space-y-1">
                  <label className="text-xs text-slate-300">Your Full Name / Company Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mr. Tariq / Textile Mill"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-xl p-3 text-xs text-white focus:border-[#C5A267] outline-none"
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs text-slate-300">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      placeholder="+92 300 1234567"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-xl p-3 text-xs text-white focus:border-[#C5A267] outline-none"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-slate-300">Email Address</label>
                    <input
                      type="email"
                      placeholder="client@domain.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-xl p-3 text-xs text-white focus:border-[#C5A267] outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-300">Project Requirements & Scope *</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Tell us about your project requirements (e.g. 50kW Solar System in SITE area, DB panel wiring, Fire Alarm System setup)..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-xl p-3 text-xs text-white focus:border-[#C5A267] outline-none"
                  />
                </div>

                <div className="pt-2 flex items-center justify-between gap-3">
                  <a
                    href={`https://wa.me/${COMPANY_INFO.contact.whatsapp}?text=Hello%20Voltix%20Solutions,%20I%20have%20a%20project%20inquiry.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-3 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>WhatsApp Us</span>
                  </a>

                  <button
                    type="submit"
                    className="bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] font-extrabold px-6 py-3 rounded-xl text-xs shadow-lg flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Submit Inquiry</span>
                  </button>
                </div>

              </form>
            )}

          </div>

        </div>

        {/* Owner / Staff Access Link (Protected by PIN) */}
        <div className="mt-12 pt-6 border-t border-[#2A2A32]/60 text-center flex items-center justify-center gap-2 text-xs text-slate-500">
          <Lock className="w-3.5 h-3.5 text-slate-500" />
          <span>Voltix Staff Portal:</span>
          <button
            onClick={() => setShowOwnerPortal(true)}
            className="text-[#C5A267] hover:underline font-semibold cursor-pointer flex items-center gap-1"
          >
            <span>🔒 Owner Management Portal Login</span>
          </button>
        </div>

      </div>

      {/* Owner Admin Modal */}
      <OwnerAdminPortal
        isOpen={showOwnerPortal}
        onClose={() => setShowOwnerPortal(false)}
      />
    </section>
  );
};

