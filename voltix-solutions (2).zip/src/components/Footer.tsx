import React from 'react';
import { Zap, Phone, Mail, MapPin, MessageSquare, ChevronRight, HardHat } from 'lucide-react';
import { COMPANY_INFO, SERVICES_DATA } from '../data/companyData';
import { PageId } from './Header';

interface FooterProps {
  onOpenInspection: () => void;
  onOpenQuote: () => void;
  onNavigate?: (page: PageId) => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenInspection,
  onOpenQuote,
  onNavigate
}) => {
  const handleLinkClick = (id: PageId) => {
    if (onNavigate) {
      onNavigate(id);
    } else {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <footer className="bg-[#0A0A0B] text-slate-300 border-t border-[#2A2A32] relative pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          
          {/* Col 1: Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#121217] rounded-lg p-0.5 border border-[#C5A267] flex items-center justify-center shadow">
                <Zap className="w-5 h-5 text-[#C5A267]" />
              </div>
              <div>
                <span className="text-lg font-black text-white font-serif">VOLTIX </span>
                <span className="text-lg font-bold text-[#38BDF8]">SOLUTIONS</span>
                <p className="text-[10px] text-[#C5A267] uppercase tracking-wider font-semibold">
                  Powering Innovation • Delivering Excellence
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed font-light">
              Leading Engineering & Technical Services Company in Karachi, Pakistan providing Electrical, Solar, HVAC, Plumbing, Fire Safety, CCTV, and Maintenance solutions.
            </p>

            <div className="pt-2 flex items-center gap-2">
              <button
                onClick={onOpenInspection}
                className="bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] font-extrabold px-3 py-2 rounded-lg text-xs flex items-center gap-1.5 transition-all shadow cursor-pointer"
              >
                <HardHat className="w-3.5 h-3.5" />
                <span>Book Survey</span>
              </button>
              <button
                onClick={onOpenQuote}
                className="bg-[#121217] hover:bg-[#181822] text-white px-3 py-2 rounded-lg text-xs font-semibold border border-[#2A2A32] cursor-pointer"
              >
                <span>Estimator</span>
              </button>
            </div>
          </div>

          {/* Col 2: Engineering Divisions */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-serif border-b border-[#2A2A32] pb-2">
              Our 8 Divisions
            </h4>
            <ul className="space-y-2 text-xs">
              {SERVICES_DATA.map(s => (
                <li key={s.id}>
                  <button
                    onClick={() => handleLinkClick('services')}
                    className="hover:text-[#C5A267] transition-colors flex items-center gap-1.5 text-slate-400 font-light text-left cursor-pointer"
                  >
                    <ChevronRight className="w-3 h-3 text-[#38BDF8]" />
                    <span>{s.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Quick Navigation */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-serif border-b border-[#2A2A32] pb-2">
              Quick Links
            </h4>
            <ul className="space-y-2 text-xs font-light">
              <li>
                <button onClick={() => handleLinkClick('about')} className="text-slate-400 hover:text-[#C5A267] transition-colors cursor-pointer">
                  About Voltix Solutions
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('services')} className="text-slate-400 hover:text-[#C5A267] transition-colors cursor-pointer">
                  Service Directory & Specs
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('solar')} className="text-[#C5A267] font-semibold hover:underline transition-colors cursor-pointer">
                  Solar ROI & Savings Calculator
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('cctv')} className="text-slate-400 hover:text-[#C5A267] transition-colors cursor-pointer">
                  CCTV Surveillance & Security
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('industries')} className="text-slate-400 hover:text-[#C5A267] transition-colors cursor-pointer">
                  Industries We Serve
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('contact')} className="text-slate-400 hover:text-[#C5A267] transition-colors cursor-pointer">
                  Head Office Map & Contact
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact Summary */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-serif border-b border-[#2A2A32] pb-2">
              Head Office Contact
            </h4>
            
            <div className="space-y-2 text-xs text-slate-300 font-light">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{COMPANY_INFO.contact.address}</span>
              </div>

              <div className="flex items-center gap-2 font-mono">
                <Phone className="w-4 h-4 text-[#38BDF8] shrink-0" />
                <a href={`tel:${COMPANY_INFO.contact.phone1Raw}`} className="hover:text-[#C5A267] font-bold">
                  {COMPANY_INFO.contact.phone1}
                </a>
              </div>

              <div className="flex items-center gap-2 font-mono">
                <Phone className="w-4 h-4 text-[#38BDF8] shrink-0" />
                <a href={`tel:${COMPANY_INFO.contact.phone2Raw}`} className="hover:text-[#C5A267] font-bold">
                  {COMPANY_INFO.contact.phone2}
                </a>
              </div>

              <div className="flex items-center gap-2 font-mono">
                <Mail className="w-4 h-4 text-[#C5A267] shrink-0" />
                <a href={`mailto:${COMPANY_INFO.contact.email}`} className="hover:text-[#C5A267] break-all">
                  {COMPANY_INFO.contact.email}
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-6 border-t border-[#2A2A32] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 font-light">
          <div>
            © {new Date().getFullYear()} <strong className="text-slate-200">VOLTIX SOLUTIONS PVT LTD</strong>. All Rights Reserved.
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Electrical • Solar • HVAC • Plumbing • Fire Safety • CCTV</span>
          </div>
        </div>

      </div>

      {/* Sticky Bottom-Left Floating WhatsApp Button */}
      <a
        href={`https://wa.me/${COMPANY_INFO.contact.whatsapp}?text=Hello%20Voltix%20Solutions,%20I%20am%20interested%20in%20your%20services.`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 left-6 z-40 bg-emerald-600 hover:bg-emerald-500 text-white p-3.5 rounded-full shadow-2xl hover:scale-110 transition-all flex items-center gap-2 border border-white/20"
        title="Direct WhatsApp Chat"
      >
        <MessageSquare className="w-6 h-6 fill-white text-emerald-600" />
        <span className="text-xs font-bold hidden sm:inline">WhatsApp Chat</span>
      </a>

    </footer>
  );
};

