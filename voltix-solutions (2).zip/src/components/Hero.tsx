import React from 'react';
import { 
  Zap, 
  Sun, 
  Wrench, 
  Thermometer, 
  Flame, 
  Video, 
  HardHat, 
  ArrowRight, 
  CheckCircle2, 
  PhoneCall, 
  ShieldCheck,
  Building2 
} from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';

interface HeroProps {
  onOpenInspection: () => void;
  onOpenQuote: () => void;
  onNavigate?: (pageId: any) => void;
}

export const Hero: React.FC<HeroProps> = ({
  onOpenInspection,
  onOpenQuote,
  onNavigate
}) => {
  return (
    <section className="relative bg-[#0A0A0B] text-slate-100 overflow-hidden pt-8 pb-16 lg:py-20 border-b border-[#2A2A32]">
      {/* Sophisticated Dark Atmosphere Accents */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-bl from-[#C5A267]/10 via-transparent to-transparent pointer-events-none" />
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#C5A267] via-[#38BDF8] to-[#C5A267]" />
      
      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-12 gap-10 items-center">
          
          {/* Main Hero Copy & CTAs */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Tagline Badge */}
            <div className="inline-flex items-center gap-2 bg-[#121217] border border-[#C5A267]/50 rounded-full px-4 py-1.5 text-xs sm:text-sm font-semibold text-[#C5A267] shadow-md backdrop-blur">
              <Zap className="w-4 h-4 fill-[#C5A267]" />
              <span>{COMPANY_INFO.tagline}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black tracking-tight leading-tight text-white font-serif">
              Complete Engineering <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#38BDF8] via-slate-100 to-[#C5A267]">
                & Technical Solutions
              </span>
            </h1>

            {/* Subtext */}
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-2xl font-light">
              {COMPANY_INFO.aboutEnglish}
            </p>

            {/* Bullet Highlights */}
            <div className="grid sm:grid-cols-2 gap-3 text-xs sm:text-sm font-medium pt-1 text-slate-200">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#C5A267] shrink-0" />
                <span>24/7 Rapid Emergency Dispatch</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#C5A267] shrink-0" />
                <span>PEC Certified Engineering Team</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#C5A267] shrink-0" />
                <span>K-Electric Net Metering Approved</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#C5A267] shrink-0" />
                <span>Transparent Turnkey Estimates</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onOpenInspection}
                className="bg-gradient-to-r from-[#C5A267] to-[#A88448] hover:from-[#D8B77D] hover:to-[#B89458] text-[#0A0A0B] font-extrabold px-6 py-3.5 rounded-xl shadow-xl transition-all flex items-center gap-2 text-sm sm:text-base cursor-pointer transform hover:-translate-y-0.5"
              >
                <HardHat className="w-5 h-5" />
                <span>Book Free Technical Site Survey</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenQuote}
                className="bg-[#121217] hover:bg-[#181822] border border-[#2A2A32] text-slate-200 font-semibold px-5 py-3.5 rounded-xl shadow transition-all text-sm sm:text-base cursor-pointer flex items-center gap-2"
              >
                <span>Instant Cost Estimator</span>
              </button>

              <a
                href={`tel:${COMPANY_INFO.contact.phone1Raw}`}
                className="inline-flex items-center gap-2 text-slate-300 hover:text-white px-3 py-3 text-sm font-medium underline-offset-4 hover:underline"
              >
                <PhoneCall className="w-4 h-4 text-[#38BDF8]" />
                <span className="font-mono">{COMPANY_INFO.contact.phone1}</span>
              </a>
            </div>

            {/* Quick Division Badges */}
            <div className="pt-4 border-t border-[#1E1E24]">
              <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-3">
                Core Engineering Divisions:
              </p>
              <div className="flex flex-wrap gap-2 text-xs">
                <button 
                  onClick={() => onNavigate && onNavigate('services')}
                  className="inline-flex items-center gap-1.5 bg-[#121217] border border-[#2A2A32] text-slate-300 hover:text-[#C5A267] px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5 text-[#C5A267]" /> Electrical Work
                </button>
                <button 
                  onClick={() => onNavigate && onNavigate('solar')}
                  className="inline-flex items-center gap-1.5 bg-[#121217] border border-[#2A2A32] text-slate-300 hover:text-[#C5A267] px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  <Sun className="w-3.5 h-3.5 text-amber-400" /> Solar Energy
                </button>
                <button 
                  onClick={() => onNavigate && onNavigate('services')}
                  className="inline-flex items-center gap-1.5 bg-[#121217] border border-[#2A2A32] text-slate-300 hover:text-[#C5A267] px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  <Thermometer className="w-3.5 h-3.5 text-cyan-400" /> HVAC / AC
                </button>
                <button 
                  onClick={() => onNavigate && onNavigate('services')}
                  className="inline-flex items-center gap-1.5 bg-[#121217] border border-[#2A2A32] text-slate-300 hover:text-[#C5A267] px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  <Flame className="w-3.5 h-3.5 text-rose-400" /> Fire Safety
                </button>
                <button 
                  onClick={() => onNavigate && onNavigate('cctv')}
                  className="inline-flex items-center gap-1.5 bg-[#121217] border border-[#2A2A32] text-slate-300 hover:text-[#C5A267] px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  <Video className="w-3.5 h-3.5 text-blue-400" /> CCTV Security
                </button>
                <button 
                  onClick={() => onNavigate && onNavigate('services')}
                  className="inline-flex items-center gap-1.5 bg-[#121217] border border-[#2A2A32] text-slate-300 hover:text-[#C5A267] px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  <Wrench className="w-3.5 h-3.5 text-emerald-400" /> Plumbing & AMC
                </button>
              </div>
            </div>
          </div>

          {/* Right Visual Collage */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none space-y-4">
              
              {/* Main Photo Container */}
              <div className="relative rounded-2xl overflow-hidden bg-[#121217] border border-[#C5A267]/40 p-1.5 shadow-2xl group">
                <div className="relative h-64 sm:h-72 rounded-xl overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&q=80&w=1000"
                    alt="Voltix Solutions Engineering Plant"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B] via-transparent to-transparent opacity-85" />
                  
                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <span className="bg-[#C5A267] text-[#0A0A0B] text-[10px] font-black tracking-widest uppercase px-2.5 py-1 rounded">
                      Karachi Headquartered
                    </span>
                    <h3 className="text-lg font-bold mt-1 text-white font-serif">
                      Industrial & Commercial MEP Engineering
                    </h3>
                    <p className="text-xs text-slate-300">
                      Plot # A-150, Korangi No.6 Market Opp. Islamia Ground, Karachi
                    </p>
                  </div>
                </div>
              </div>

              {/* Sub Cards Grid */}
              <div className="grid grid-cols-2 gap-3">
                <div 
                  onClick={() => onNavigate && onNavigate('solar')}
                  className="bg-[#121217] border border-[#2A2A32] hover:border-[#C5A267] rounded-xl p-3.5 text-left space-y-1 shadow-lg cursor-pointer transition-all"
                >
                  <div className="w-8 h-8 rounded-lg bg-[#38BDF8]/20 border border-[#38BDF8]/40 flex items-center justify-center text-[#38BDF8]">
                    <Sun className="w-4 h-4" />
                  </div>
                  <div className="text-sm font-bold text-white font-serif">Solar Systems</div>
                  <p className="text-[11px] text-slate-400">On-Grid, Hybrid & Net Metering</p>
                </div>

                <div 
                  onClick={() => onNavigate && onNavigate('cctv')}
                  className="bg-[#121217] border border-[#2A2A32] hover:border-[#C5A267] rounded-xl p-3.5 text-left space-y-1 shadow-lg cursor-pointer transition-all"
                >
                  <div className="w-8 h-8 rounded-lg bg-[#C5A267]/20 border border-[#C5A267]/40 flex items-center justify-center text-[#C5A267]">
                    <Video className="w-4 h-4" />
                  </div>
                  <div className="text-sm font-bold text-white font-serif">CCTV & Alarms</div>
                  <p className="text-[11px] text-slate-400">4K Remote Live Viewing & Security</p>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Stats Counter Bar Below Hero */}
        <div className="mt-12 pt-8 border-t border-[#2A2A32] grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="bg-[#121217] border border-[#2A2A32] p-4 rounded-xl">
            <div className="text-2xl sm:text-3xl font-black text-[#C5A267] font-serif">500+</div>
            <div className="text-xs text-slate-400 mt-0.5">Projects Delivered</div>
          </div>
          <div className="bg-[#121217] border border-[#2A2A32] p-4 rounded-xl">
            <div className="text-2xl sm:text-3xl font-black text-[#38BDF8] font-serif">8</div>
            <div className="text-xs text-slate-400 mt-0.5">Specialized Divisions</div>
          </div>
          <div className="bg-[#121217] border border-[#2A2A32] p-4 rounded-xl">
            <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-serif">100%</div>
            <div className="text-xs text-slate-400 mt-0.5">PEC & K-Electric Compliance</div>
          </div>
          <div className="bg-[#121217] border border-[#2A2A32] p-4 rounded-xl">
            <div className="text-2xl sm:text-3xl font-black text-amber-400 font-serif">24/7</div>
            <div className="text-xs text-slate-400 mt-0.5">Emergency Engineer Response</div>
          </div>
        </div>

      </div>
    </section>
  );
};

