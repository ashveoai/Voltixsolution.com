import React, { useState, useEffect } from 'react';
import { Lock, KeyRound, Phone, MessageSquare, Trash2, RefreshCw, Shield, Download, Search, X, Mail, CheckCircle2, ArrowLeft, Key, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';

interface InquiryRecord {
  id: string;
  name: string;
  phone: string;
  email?: string;
  message: string;
  serviceType?: string;
  timestamp: string;
  status?: 'new' | 'contacted' | 'completed';
}

interface OwnerAdminPortalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OwnerAdminPortal: React.FC<OwnerAdminPortalProps> = ({ isOpen, onClose }) => {
  const [pinInput, setPinInput] = useState('');
  const [showPinText, setShowPinText] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [pinError, setPinError] = useState(false);
  
  // Active PIN stored in localStorage (default: 1234 if first time)
  const [storedPin, setStoredPin] = useState(() => {
    return localStorage.getItem('voltix_admin_pin') || '1234';
  });

  // Owner Secret Master Key (default: VOLTIX2026)
  const [masterKey, setMasterKey] = useState(() => {
    return localStorage.getItem('voltix_master_key') || 'VOLTIX2026';
  });

  // Forgot PIN Recovery State
  const [isForgotMode, setIsForgotMode] = useState(false);
  const [verifyEmail, setVerifyEmail] = useState('');
  const [verifyMasterKey, setVerifyMasterKey] = useState('');
  const [recoveryError, setRecoveryError] = useState('');
  const [recoverySuccess, setRecoverySuccess] = useState(false);
  const [resetNewPin, setResetNewPin] = useState('');

  // Dashboard state
  const [inquiries, setInquiries] = useState<InquiryRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'new' | 'contacted' | 'completed'>('all');
  const [changePinMode, setChangePinMode] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [newMasterKeyInput, setNewMasterKeyInput] = useState('');

  // Fetch inquiries from server and local storage
  const fetchInquiries = async () => {
    setLoading(true);
    let combined: InquiryRecord[] = [];

    // 1. Get local storage items
    try {
      const local = JSON.parse(localStorage.getItem('voltix_inquiries') || '[]');
      combined = [...local];
    } catch (err) {
      console.error("Local storage read error", err);
    }

    // 2. Get server API items
    try {
      const res = await fetch('/api/inquiries');
      if (res.ok) {
        const data = await res.json();
        if (data && Array.isArray(data.inquiries)) {
          const existingIds = new Set(combined.map(i => i.id));
          for (const serverInq of data.inquiries) {
            if (!existingIds.has(serverInq.id)) {
              combined.push(serverInq);
            }
          }
        }
      }
    } catch (err) {
      console.error("Server API fetch error", err);
    }

    // Sort newest first
    combined.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    setInquiries(combined);
    setLoading(false);
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchInquiries();
    }
  }, [isAuthenticated]);

  if (!isOpen) return null;

  // STRICT LOGIN - Checks ONLY active storedPin
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() === storedPin) {
      setIsAuthenticated(true);
      setPinError(false);
      setPinInput('');
    } else {
      setPinError(true);
    }
  };

  // Change PIN inside Dashboard
  const handleChangePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.trim().length >= 4) {
      const updated = newPin.trim();
      localStorage.setItem('voltix_admin_pin', updated);
      setStoredPin(updated);

      if (newMasterKeyInput.trim().length >= 4) {
        localStorage.setItem('voltix_master_key', newMasterKeyInput.trim());
        setMasterKey(newMasterKeyInput.trim());
      }

      setChangePinMode(false);
      setNewPin('');
      setNewMasterKeyInput('');
      alert("✅ Owner Access PIN updated successfully! The new PIN is active immediately.");
    } else {
      alert("❌ PIN must be at least 4 digits.");
    }
  };

  // Verify Owner Credentials for Reset
  const handleVerifyForgotPin = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError('');

    const cleanEmail = verifyEmail.trim().toLowerCase();
    const cleanKey = verifyMasterKey.trim();

    // Check if email matches company email and master key matches stored masterKey or VOLTIX2026
    const isOwnerEmailValid = cleanEmail === COMPANY_INFO.contact.email.toLowerCase() || cleanEmail === 'voltixsolutionpvtpk@gmail.com';
    const isMasterKeyValid = cleanKey === masterKey || cleanKey === 'VOLTIX2026' || cleanKey === 'voltix2026';

    if (isOwnerEmailValid && isMasterKeyValid) {
      setRecoverySuccess(true);
    } else {
      if (!isOwnerEmailValid) {
        setRecoveryError("Invalid Owner Email. Must match official company registration email.");
      } else {
        setRecoveryError("Invalid Master Recovery Key. Contact system admin if you forgot your master key.");
      }
    }
  };

  // Save New PIN after Recovery
  const handleSaveResetPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (resetNewPin.trim().length >= 4) {
      const updated = resetNewPin.trim();
      localStorage.setItem('voltix_admin_pin', updated);
      setStoredPin(updated);
      alert("✅ Password Reset Successful! Logging in with your new PIN.");
      
      // Reset state and log in
      setIsForgotMode(false);
      setRecoverySuccess(false);
      setVerifyEmail('');
      setVerifyMasterKey('');
      setResetNewPin('');
      setIsAuthenticated(true);
    } else {
      alert("❌ PIN must be at least 4 digits.");
    }
  };

  const updateStatus = (id: string, newStatus: 'new' | 'contacted' | 'completed') => {
    const updated = inquiries.map(inq => inq.id === id ? { ...inq, status: newStatus } : inq);
    setInquiries(updated);
    localStorage.setItem('voltix_inquiries', JSON.stringify(updated));
  };

  const deleteInquiry = (id: string) => {
    if (confirm("Are you sure you want to delete this customer record?")) {
      const filtered = inquiries.filter(inq => inq.id !== id);
      setInquiries(filtered);
      localStorage.setItem('voltix_inquiries', JSON.stringify(filtered));
    }
  };

  const exportCSV = () => {
    if (inquiries.length === 0) return alert("No inquiries to export.");
    const headers = ["ID,Name,Phone,Email,Message,Timestamp,Status"];
    const rows = inquiries.map(i => 
      `"${i.id}","${i.name}","${i.phone}","${i.email || ''}","${(i.message || '').replace(/"/g, '""')}","${i.timestamp}","${i.status || 'new'}"`
    );
    const csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Voltix_Inquiries_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredInquiries = inquiries.filter(inq => {
    const matchesSearch = 
      inq.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inq.phone.includes(searchTerm) ||
      (inq.message && inq.message.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (statusFilter === 'all') return matchesSearch;
    return matchesSearch && (inq.status || 'new') === statusFilter;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#121217] border border-[#C5A267] w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] text-white">
        
        {/* Portal Header */}
        <div className="bg-[#0A0A0B] p-5 border-b border-[#2A2A32] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#C5A267]/20 border border-[#C5A267] flex items-center justify-center text-[#C5A267]">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white font-serif flex items-center gap-2">
                <span>Voltix Solutions - Owner Management Portal</span>
                <span className="text-[10px] bg-[#C5A267]/20 text-[#C5A267] border border-[#C5A267]/40 px-2 py-0.5 rounded uppercase font-sans">
                  Owner Restricted
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Secure lead dispatches, customer inquiry tracking & response system
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-rose-600/30 rounded-lg transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* BODY */}
        {!isAuthenticated ? (
          /* LOGIN OR FORGOT PIN FLOW */
          <div className="p-6 sm:p-10 text-center max-w-md mx-auto my-auto space-y-6 w-full">
            
            {!isForgotMode ? (
              /* LOGIN SCREEN */
              <div className="space-y-5">
                <div className="w-16 h-16 rounded-full bg-[#C5A267]/10 border border-[#C5A267] flex items-center justify-center text-[#C5A267] mx-auto shadow-lg">
                  <Lock className="w-8 h-8" />
                </div>

                <div>
                  <h4 className="text-xl font-bold text-white font-serif">
                    Owner Security Access
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Enter your confidential Owner PIN to view customer inquiries & lead submissions.
                  </p>
                </div>

                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="relative">
                    <input
                      type={showPinText ? 'text' : 'password'}
                      value={pinInput}
                      onChange={(e) => {
                        setPinInput(e.target.value);
                        setPinError(false);
                      }}
                      placeholder="Enter Owner Access PIN"
                      className="w-full bg-[#0A0A0B] border border-[#2A2A32] focus:border-[#C5A267] rounded-xl px-4 py-3 text-center text-lg font-mono tracking-widest text-white outline-none pr-12"
                      autoFocus
                    />
                    <button
                      type="button"
                      onClick={() => setShowPinText(!showPinText)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 p-1 cursor-pointer"
                    >
                      {showPinText ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>

                  {pinError && (
                    <p className="text-xs text-rose-400 font-semibold text-center flex items-center justify-center gap-1">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>Access Denied. Incorrect PIN entered.</span>
                    </p>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] font-bold py-3 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg text-sm"
                  >
                    <KeyRound className="w-4 h-4" />
                    <span>Unlock Owner Portal</span>
                  </button>
                </form>

                <div className="pt-3 border-t border-[#2A2A32] flex items-center justify-between text-xs text-slate-400">
                  <span>Forgot access PIN?</span>
                  <button
                    onClick={() => {
                      setIsForgotMode(true);
                      setRecoveryError('');
                      setRecoverySuccess(false);
                    }}
                    className="text-[#C5A267] hover:underline font-semibold cursor-pointer flex items-center gap-1"
                  >
                    <Key className="w-3.5 h-3.5" />
                    <span>Owner Verification Reset</span>
                  </button>
                </div>
              </div>
            ) : (
              /* FORGOT PIN OWNER RECOVERY FLOW */
              <div className="space-y-5 text-left">
                <button
                  onClick={() => setIsForgotMode(false)}
                  className="text-xs text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer mb-2"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Login</span>
                </button>

                <div className="text-center">
                  <div className="w-14 h-14 rounded-full bg-[#C5A267]/10 border border-[#C5A267] flex items-center justify-center text-[#C5A267] mx-auto mb-2">
                    <Key className="w-7 h-7" />
                  </div>
                  <h4 className="text-lg font-bold text-white font-serif">
                    Owner Identity Reset Verification
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Verify official company credentials to configure a new PIN
                  </p>
                </div>

                {!recoverySuccess ? (
                  <form onSubmit={handleVerifyForgotPin} className="space-y-4">
                    <div>
                      <label className="text-xs text-slate-300 font-semibold mb-1 block">
                        Official Owner Email:
                      </label>
                      <input
                        type="email"
                        value={verifyEmail}
                        onChange={(e) => setVerifyEmail(e.target.value)}
                        placeholder="e.g. voltixsolutionpvtpk@gmail.com"
                        className="w-full bg-[#0A0A0B] border border-[#2A2A32] focus:border-[#C5A267] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-xs text-slate-300 font-semibold mb-1 block">
                        Master Recovery Security Key:
                      </label>
                      <input
                        type="password"
                        value={verifyMasterKey}
                        onChange={(e) => setVerifyMasterKey(e.target.value)}
                        placeholder="Enter Master Key (Default: VOLTIX2026)"
                        className="w-full bg-[#0A0A0B] border border-[#2A2A32] focus:border-[#C5A267] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none font-mono"
                        required
                      />
                    </div>

                    {recoveryError && (
                      <div className="p-3 bg-rose-950/60 border border-rose-500/40 rounded-xl text-xs text-rose-300 space-y-1">
                        <div className="font-bold flex items-center gap-1">
                          <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                          <span>Verification Failed</span>
                        </div>
                        <p className="text-[11px] text-slate-300">{recoveryError}</p>
                        <p className="text-[10px] text-slate-400 pt-1">
                          Need help? Call System Admin directly at{' '}
                          <a href={`tel:${COMPANY_INFO.contact.phone1Raw}`} className="text-[#C5A267] underline">
                            {COMPANY_INFO.contact.phone1}
                          </a>
                        </p>
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] font-bold py-3 rounded-xl transition-all cursor-pointer text-xs shadow-lg"
                    >
                      Verify Credentials & Unlock Reset
                    </button>
                  </form>
                ) : (
                  <form onSubmit={handleSaveResetPin} className="space-y-4">
                    <div className="p-3 bg-emerald-500/20 border border-emerald-500 rounded-xl text-xs text-emerald-300 font-semibold flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                      <span>Owner Verification Passed! Enter your new PIN below:</span>
                    </div>

                    <div>
                      <label className="text-xs text-slate-300 font-semibold mb-1 block">
                        Set New Owner PIN (4+ digits):
                      </label>
                      <input
                        type="password"
                        value={resetNewPin}
                        onChange={(e) => setResetNewPin(e.target.value)}
                        placeholder="Enter New Confidential PIN"
                        className="w-full bg-[#0A0A0B] border border-[#C5A267] rounded-xl px-4 py-3 text-center text-lg font-mono tracking-widest text-white outline-none"
                        autoFocus
                        required
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl transition-all cursor-pointer text-xs shadow-lg"
                    >
                      Save New PIN & Log In
                    </button>
                  </form>
                )}

              </div>
            )}

          </div>
        ) : (
          /* AUTHENTICATED OWNER DASHBOARD */
          <div className="p-6 flex-1 flex flex-col overflow-hidden space-y-4">
            
            {/* Top Toolbar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#0A0A0B] p-3.5 rounded-xl border border-[#2A2A32]">
              <div className="flex items-center gap-2 flex-1">
                <Search className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type="text"
                  placeholder="Search by customer name, phone, or service..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-transparent text-xs text-white placeholder-slate-500 outline-none w-full"
                />
              </div>

              {/* Status Filters */}
              <div className="flex items-center gap-1.5 text-xs">
                <button
                  onClick={() => setStatusFilter('all')}
                  className={`px-3 py-1.5 rounded-lg font-semibold cursor-pointer ${
                    statusFilter === 'all' ? 'bg-[#C5A267] text-[#0A0A0B]' : 'bg-[#181822] text-slate-400 hover:text-white'
                  }`}
                >
                  All ({inquiries.length})
                </button>
                <button
                  onClick={() => setStatusFilter('new')}
                  className={`px-3 py-1.5 rounded-lg font-semibold cursor-pointer ${
                    statusFilter === 'new' ? 'bg-amber-500 text-slate-950' : 'bg-[#181822] text-slate-400 hover:text-white'
                  }`}
                >
                  New
                </button>
                <button
                  onClick={() => setStatusFilter('contacted')}
                  className={`px-3 py-1.5 rounded-lg font-semibold cursor-pointer ${
                    statusFilter === 'contacted' ? 'bg-sky-500 text-slate-950' : 'bg-[#181822] text-slate-400 hover:text-white'
                  }`}
                >
                  Contacted
                </button>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 border-l border-[#2A2A32] pl-3">
                <button
                  onClick={fetchInquiries}
                  className="p-2 bg-[#181822] hover:bg-[#22222E] text-slate-300 rounded-lg cursor-pointer"
                  title="Refresh Inquiries"
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                </button>
                <button
                  onClick={exportCSV}
                  className="px-3 py-1.5 bg-emerald-600/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-600/30 rounded-lg text-xs font-semibold cursor-pointer flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export CSV</span>
                </button>
              </div>
            </div>

            {/* Inquiries List */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              {filteredInquiries.length === 0 ? (
                <div className="text-center py-16 bg-[#0A0A0B] rounded-xl border border-[#2A2A32] space-y-2">
                  <p className="text-sm font-semibold text-slate-300">No customer inquiries found.</p>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    When customers submit forms or request site visits, their details will appear here instantly.
                  </p>
                </div>
              ) : (
                filteredInquiries.map((inq) => {
                  const status = inq.status || 'new';
                  return (
                    <div
                      key={inq.id}
                      className="bg-[#0A0A0B] p-4 rounded-xl border border-[#2A2A32] hover:border-[#C5A267]/60 transition-all space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#181822]">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm font-serif">
                            {inq.name}
                          </span>
                          <span className="font-mono text-xs text-[#C5A267] bg-[#C5A267]/10 px-2 py-0.5 rounded border border-[#C5A267]/20">
                            {inq.phone}
                          </span>
                          {inq.email && inq.email !== 'N/A' && (
                            <span className="text-xs text-slate-400 hidden md:inline">
                              • {inq.email}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-xs">
                          <span className="text-[11px] text-slate-500 font-mono">
                            {inq.timestamp}
                          </span>
                          <select
                            value={status}
                            onChange={(e) => updateStatus(inq.id, e.target.value as any)}
                            className={`text-xs px-2.5 py-1 rounded font-bold outline-none cursor-pointer ${
                              status === 'new'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                : status === 'contacted'
                                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            }`}
                          >
                            <option value="new" className="bg-[#121217] text-amber-300">🟡 NEW LEAD</option>
                            <option value="contacted" className="bg-[#121217] text-sky-300">🔵 CONTACTED</option>
                            <option value="completed" className="bg-[#121217] text-emerald-300">🟢 COMPLETED</option>
                          </select>
                        </div>
                      </div>

                      {/* Inquiry Content */}
                      <p className="text-xs text-slate-200 bg-[#121217] p-3 rounded-lg border border-[#181822] leading-relaxed">
                        {inq.message}
                      </p>

                      {/* Owner Reply Actions */}
                      <div className="flex items-center justify-between pt-1">
                        <div className="flex items-center gap-2">
                          <a
                            href={`https://wa.me/${inq.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                              `Hello ${inq.name}, this is Voltix Solutions engineering team regarding your website inquiry: "${inq.message.slice(0, 50)}..."`
                            )}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shadow"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Reply via WhatsApp</span>
                          </a>

                          <a
                            href={`tel:${inq.phone}`}
                            className="px-3 py-1.5 bg-[#181822] hover:bg-[#22222E] text-slate-200 border border-[#2A2A32] rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5"
                          >
                            <Phone className="w-3.5 h-3.5 text-[#38BDF8]" />
                            <span>Call Customer</span>
                          </a>
                        </div>

                        <button
                          onClick={() => deleteInquiry(inq.id)}
                          className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 rounded-lg transition-all cursor-pointer"
                          title="Delete Record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Bottom Admin Bar */}
            <div className="pt-3 border-t border-[#2A2A32] flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setChangePinMode(!changePinMode)}
                  className="text-[#C5A267] hover:underline font-semibold cursor-pointer"
                >
                  ⚙️ Update PIN / Master Key Settings
                </button>
              </div>

              {changePinMode && (
                <form onSubmit={handleChangePin} className="flex flex-wrap items-center gap-2 bg-[#0A0A0B] p-2 rounded-xl border border-[#2A2A32]">
                  <input
                    type="password"
                    placeholder="New PIN (4+ digits)"
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    className="bg-[#121217] border border-[#C5A267] text-white text-xs px-2.5 py-1 rounded font-mono outline-none w-32"
                    required
                  />
                  <input
                    type="password"
                    placeholder="New Master Key (Optional)"
                    value={newMasterKeyInput}
                    onChange={(e) => setNewMasterKeyInput(e.target.value)}
                    className="bg-[#121217] border border-[#2A2A32] text-white text-xs px-2.5 py-1 rounded font-mono outline-none w-36"
                  />
                  <button type="submit" className="bg-[#C5A267] text-[#0A0A0B] font-bold px-3 py-1 rounded cursor-pointer">
                    Save Changes
                  </button>
                </form>
              )}

              <button
                onClick={() => setIsAuthenticated(false)}
                className="bg-rose-600/20 text-rose-300 border border-rose-500/40 px-3 py-1 rounded-lg hover:bg-rose-600/30 cursor-pointer font-semibold"
              >
                Lock Portal
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
