import React, { useState } from 'react';
import { Bot, Send, X, Sparkles, RefreshCw } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';

export const AiAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'bot'; text: string }>>([
    {
      sender: 'bot',
      text: "Welcome to Voltix Solutions! I am your AI Technical Engineering Consultant. Ask me anything about Solar system sizing, DB panel wiring, Fire Safety compliance, CCTV packages, or HVAC ton calculations."
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sampleQuestions = [
    "Solar cost for PKR 60,000 monthly bill?",
    "CCTV package estimate for 8 cameras?",
    "AC tonnage calculation for 200 sq ft room?",
    "Fire alarm requirements for commercial plant?"
  ];

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim() || loading) return;

    const userMsg = query.trim();
    setInput('');
    setMessages(prev => [...prev, { sender: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const res = await fetch('/api/ai-consultant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMsg })
      });
      const data = await res.json();
      setMessages(prev => [...prev, { sender: 'bot', text: data.reply || "Thank you. Please call +92 300 2667840 for direct engineering consultation." }]);
    } catch (err) {
      setMessages(prev => [...prev, {
        sender: 'bot',
        text: "Voltix Solutions provides full Electrical, Solar, HVAC, Fire Safety, and CCTV engineering services in Karachi. Call +92 300 2667840 or WhatsApp +92 304 2510042 to speak directly with our senior engineers."
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating Toggle Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 z-40 bg-gradient-to-r from-[#C5A267] to-[#A88448] text-[#0A0A0B] p-3.5 sm:p-4 rounded-full shadow-2xl hover:scale-105 transition-all cursor-pointer flex items-center gap-2 border border-[#C5A267]/50 ${isOpen ? 'hidden' : 'flex'}`}
        title="Chat with Voltix Engineering Assistant"
      >
        <div className="relative">
          <Bot className="w-6 h-6 stroke-[2.5]" />
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-[#0A0A0B] animate-pulse" />
        </div>
        <span className="text-xs font-black uppercase tracking-wider hidden md:inline">
          AI Engineer
        </span>
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-full max-w-sm sm:max-w-md bg-[#0A0A0B] border border-[#C5A267]/60 rounded-2xl shadow-2xl overflow-hidden flex flex-col text-slate-100 h-[520px] animate-fadeIn">
          
          {/* Header */}
          <div className="bg-[#121217] p-4 border-b border-[#2A2A32] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[#C5A267]/20 border border-[#C5A267] flex items-center justify-center text-[#C5A267]">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <span>Voltix AI Technical Agent</span>
                  <Sparkles className="w-3.5 h-3.5 text-[#C5A267]" />
                </h3>
                <span className="text-[10px] text-emerald-400 font-semibold">
                  ● Engineering & ROI Engine Active
                </span>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-rose-600/80 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Body */}
          <div className="p-4 overflow-y-auto flex-1 space-y-3 bg-[#0A0A0B]">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[88%] p-3.5 rounded-2xl text-xs leading-relaxed whitespace-pre-line ${
                    m.sender === 'user'
                      ? 'bg-[#181822] text-[#38BDF8] border border-[#38BDF8]/30 rounded-br-none font-medium'
                      : 'bg-[#121217] text-slate-200 border border-[#2A2A32] rounded-bl-none'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex justify-start">
                <div className="bg-[#121217] p-3 rounded-2xl text-xs text-slate-400 flex items-center gap-2 border border-[#2A2A32]">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#C5A267]" />
                  <span>Calculating Engineering Specs...</span>
                </div>
              </div>
            )}
          </div>

          {/* Quick Prompts */}
          <div className="p-2 bg-[#121217] border-t border-[#2A2A32] overflow-x-auto whitespace-nowrap flex gap-1.5 text-[10px]">
            {sampleQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(q)}
                className="bg-[#181822] hover:bg-[#22222E] text-slate-300 px-2.5 py-1.5 rounded-lg border border-[#2A2A32] shrink-0 cursor-pointer transition-colors"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input Footer */}
          <div className="p-3 bg-[#0A0A0B] border-t border-[#2A2A32] flex items-center gap-2">
            <input
              type="text"
              placeholder="Ask solar kW, CCTV, DB panels, fire safety..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              className="flex-1 bg-[#121217] border border-[#2A2A32] rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
            />
            <button
              onClick={() => handleSend()}
              disabled={loading}
              className="bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] p-2.5 rounded-xl transition-all cursor-pointer disabled:opacity-50 font-bold"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>

        </div>
      )}
    </>
  );
};

