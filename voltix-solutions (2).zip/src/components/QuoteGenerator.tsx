import React, { useState } from 'react';
import { FileText, CheckSquare, Printer, MessageSquare, HardHat, X } from 'lucide-react';
import { COMPANY_INFO, SERVICES_DATA } from '../data/companyData';

interface QuoteGeneratorProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenInspection: () => void;
}

export const QuoteGenerator: React.FC<QuoteGeneratorProps> = ({
  isOpen,
  onClose,
  onOpenInspection
}) => {
  const [propertyType, setPropertyType] = useState<string>('residential');
  const [propertyArea, setPropertyArea] = useState<string>('240_sqyd');
  const [selectedServices, setSelectedServices] = useState<string[]>(['electrical', 'solar']);
  const [clientName, setClientName] = useState<string>('');
  const [clientPhone, setClientPhone] = useState<string>('');
  const [clientEmail, setClientEmail] = useState<string>('');
  const [clientLocation, setClientLocation] = useState<string>('Karachi');
  const [customNotes, setCustomNotes] = useState<string>('');

  if (!isOpen) return null;

  const toggleService = (id: string) => {
    if (selectedServices.includes(id)) {
      if (selectedServices.length > 1) {
        setSelectedServices(selectedServices.filter(s => s !== id));
      }
    } else {
      setSelectedServices([...selectedServices, id]);
    }
  };

  // Estimate range logic
  const serviceRates: Record<string, number> = {
    electrical: 120000,
    solar: 650000,
    engineering: 80000,
    plumbing: 95000,
    hvac: 140000,
    'fire-safety': 180000,
    cctv: 85000,
    maintenance: 50000
  };

  const areaMultipliers: Record<string, number> = {
    '120_sqyd': 0.8,
    '240_sqyd': 1.0,
    '500_sqyd': 1.6,
    '1000_sqyd': 2.8,
    'industrial_plant': 5.5
  };

  const multiplier = areaMultipliers[propertyArea] || 1.0;
  
  const totalBaseCost = selectedServices.reduce((sum, serviceId) => {
    return sum + (serviceRates[serviceId] || 100000);
  }, 0);

  const estimatedMinCost = Math.round(totalBaseCost * multiplier * 0.9);
  const estimatedMaxCost = Math.round(totalBaseCost * multiplier * 1.15);

  const formatPkr = (val: number) => "PKR " + val.toLocaleString('en-PK');

  const handlePrint = () => {
    window.print();
  };

  const sendWhatsAppQuote = () => {
    const serviceNames = selectedServices.map(id => {
      const match = SERVICES_DATA.find(s => s.id === id);
      return match ? match.title : id;
    }).join(", ");

    const text = `VOLTIX SOLUTIONS - INSTANT PROJECT ESTIMATE REQUEST
Client Name: ${clientName || 'Valued Client'}
Phone: ${clientPhone || 'N/A'}
Property: ${propertyType.toUpperCase()} (${propertyArea.replace('_', ' ')})
Location: ${clientLocation}

Requested Engineering Scope:
${serviceNames}

Estimated Turnkey Budget: ${formatPkr(estimatedMinCost)} - ${formatPkr(estimatedMaxCost)}
Special Notes: ${customNotes || 'None'}

Please schedule a formal site inspection to finalize line-item BOQ.`;

    window.open(`https://wa.me/${COMPANY_INFO.contact.whatsapp}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#121217] border border-[#C5A267] w-full max-w-4xl rounded-2xl overflow-hidden shadow-2xl max-h-[92vh] flex flex-col text-white">
        
        {/* Modal Header */}
        <div className="bg-[#0A0A0B] p-5 border-b border-[#2A2A32] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#C5A267]/20 border border-[#C5A267] flex items-center justify-center text-[#C5A267]">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white font-serif">
                Voltix Solutions • Custom Scope & Cost Estimator
              </h3>
              <p className="text-xs text-[#38BDF8]">
                Instant Budget Estimator & BOQ Generator
              </p>
            </div>
          </div>
          
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-rose-600 rounded-lg transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* Step 1: Client Info & Property Type */}
          <div className="grid md:grid-cols-2 gap-6">
            
            <div className="space-y-4 bg-[#0A0A0B] border border-[#2A2A32] p-4 rounded-xl">
              <h4 className="text-xs uppercase font-bold text-[#38BDF8] tracking-wider">
                1. Property & Scale Selection
              </h4>
              
              <div className="space-y-2">
                <label className="text-xs text-slate-300">Sector / Property Type:</label>
                <select
                  value={propertyType}
                  onChange={(e) => setPropertyType(e.target.value)}
                  className="w-full bg-[#121217] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
                >
                  <option value="residential">Residential House / Villa</option>
                  <option value="commercial">Commercial Building / Plaza</option>
                  <option value="factory">Factory & Industrial Unit</option>
                  <option value="office">Corporate Office</option>
                  <option value="retail">Retail Shop / Showroom</option>
                  <option value="construction">Construction Site</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs text-slate-300">Approximate Covered Area:</label>
                <select
                  value={propertyArea}
                  onChange={(e) => setPropertyArea(e.target.value)}
                  className="w-full bg-[#121217] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
                >
                  <option value="120_sqyd">120 Sq Yds / Small Office (~1,000 sq ft)</option>
                  <option value="240_sqyd">240 Sq Yds / Medium Floor (~2,200 sq ft)</option>
                  <option value="500_sqyd">500 Sq Yds / Bungalow / Plaza (~4,500 sq ft)</option>
                  <option value="1000_sqyd">1000 Sq Yds / Commercial Tower (~9,000 sq ft)</option>
                  <option value="industrial_plant">Industrial Plant / Warehouse (15,000+ sq ft)</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs text-slate-300">Project Location (City/Area):</label>
                <input
                  type="text"
                  placeholder="e.g. Korangi Industrial Area, Karachi"
                  value={clientLocation}
                  onChange={(e) => setClientLocation(e.target.value)}
                  className="w-full bg-[#121217] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
                />
              </div>
            </div>

            {/* Client Contact Info */}
            <div className="space-y-4 bg-[#0A0A0B] border border-[#2A2A32] p-4 rounded-xl">
              <h4 className="text-xs uppercase font-bold text-[#C5A267] tracking-wider">
                2. Contact Details (For Quotation Record)
              </h4>

              <div className="space-y-2">
                <label className="text-xs text-slate-300">Full Name / Business Name:</label>
                <input
                  type="text"
                  placeholder="Your Name or Company Name"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  className="w-full bg-[#121217] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs text-slate-300">Phone / WhatsApp Number:</label>
                <input
                  type="tel"
                  placeholder="+92 3XX XXXXXXX"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  className="w-full bg-[#121217] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none font-mono"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs text-slate-300">Email Address (Optional):</label>
                <input
                  type="email"
                  placeholder="name@example.com"
                  value={clientEmail}
                  onChange={(e) => setClientEmail(e.target.value)}
                  className="w-full bg-[#121217] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none font-mono"
                />
              </div>
            </div>

          </div>

          {/* Step 2: Select Services Needed */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase font-bold text-white tracking-wider flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-[#C5A267]" />
              <span>3. Select Required Engineering Divisions (Multiple Allowed):</span>
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {SERVICES_DATA.map(service => {
                const isSelected = selectedServices.includes(service.id);
                return (
                  <button
                    key={service.id}
                    type="button"
                    onClick={() => toggleService(service.id)}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#181822] border-[#C5A267] text-white shadow-lg ring-1 ring-[#C5A267]'
                        : 'bg-[#0A0A0B] border-[#2A2A32] text-slate-400 hover:border-slate-500'
                    }`}
                  >
                    <span className="text-xs font-bold">{service.title}</span>
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => {}}
                      className="accent-[#C5A267]"
                    />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Special Notes */}
          <div className="space-y-2">
            <label className="text-xs text-slate-300">Special Technical Requirements / Scope Notes:</label>
            <textarea
              rows={2}
              placeholder="e.g. Need 30kW Solar System, Addressable Fire Alarm panel, 16 IP Cameras with NVR..."
              value={customNotes}
              onChange={(e) => setCustomNotes(e.target.value)}
              className="w-full bg-[#0A0A0B] border border-[#2A2A32] rounded-lg p-2.5 text-xs text-white focus:border-[#C5A267] outline-none"
            />
          </div>

          {/* Summary Box */}
          <div className="bg-[#0A0A0B] border border-[#C5A267]/60 rounded-2xl p-5 space-y-3">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2 border-b border-[#2A2A32] pb-3">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-[#C5A267]">
                  Turnkey Composite Budget Estimate
                </span>
                <div className="text-2xl sm:text-3xl font-black text-white font-mono">
                  {formatPkr(estimatedMinCost)} - {formatPkr(estimatedMaxCost)}
                </div>
              </div>
              <div className="text-right text-xs text-slate-300">
                Selected Divisions: <strong className="text-white font-mono">{selectedServices.length} Categories</strong>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 font-light italic">
              * Note: This is an automated preliminary estimate based on average industry rates in Karachi. Voltix Solutions provides precise line-item BOQs after an on-site technical inspection.
            </p>
          </div>

        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 bg-[#0A0A0B] border-t border-[#2A2A32] flex flex-wrap items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={handlePrint}
            className="bg-[#181822] hover:bg-[#22222E] text-white px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer border border-[#2A2A32]"
          >
            <Printer className="w-4 h-4 text-[#C5A267]" />
            <span>Print / Save PDF</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={sendWhatsAppQuote}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Send to WhatsApp</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenInspection();
              }}
              className="bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] font-extrabold px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow"
            >
              <HardHat className="w-4 h-4" />
              <span>Book Site Inspection</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
