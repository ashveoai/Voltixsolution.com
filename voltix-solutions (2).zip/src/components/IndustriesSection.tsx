import React from 'react';
import { Building2, Building, Factory, Briefcase, ShoppingBag, HardHat, ArrowRight } from 'lucide-react';
import { INDUSTRIES_SERVED } from '../data/companyData';

interface IndustriesSectionProps {
  onOpenInspection: () => void;
}

export const IndustriesSection: React.FC<IndustriesSectionProps> = ({ onOpenInspection }) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Building2': return <Building2 className="w-5 h-5 text-[#C5A267]" />;
      case 'Building': return <Building className="w-5 h-5 text-[#38BDF8]" />;
      case 'Factory': return <Factory className="w-5 h-5 text-amber-400" />;
      case 'Briefcase': return <Briefcase className="w-5 h-5 text-emerald-400" />;
      case 'ShoppingBag': return <ShoppingBag className="w-5 h-5 text-cyan-400" />;
      default: return <HardHat className="w-5 h-5 text-[#C5A267]" />;
    }
  };

  return (
    <section className="py-16 md:py-24 bg-[#0A0A0B] text-slate-100 relative border-b border-[#2A2A32]">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 bg-[#121217] border border-[#C5A267]/40 text-[#C5A267] text-xs uppercase font-bold px-3.5 py-1 rounded-full">
            <Building2 className="w-3.5 h-3.5 text-[#C5A267]" />
            <span>Cross-Sector Engineering Experience</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white font-serif">
            INDUSTRIES <span className="text-[#C5A267]">WE SERVE</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base font-light">
            Voltix Solutions delivers tailored MEP, Solar, and Security engineering to specialized property sectors across Karachi & Pakistan.
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-[#C5A267] to-[#38BDF8] mx-auto rounded-full" />
        </div>

        {/* Industry Cards Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {INDUSTRIES_SERVED.map((ind) => (
            <div
              key={ind.id}
              className="bg-[#121217] border border-[#2A2A32] hover:border-[#C5A267]/60 rounded-2xl overflow-hidden shadow-xl transition-all duration-300 hover:-translate-y-1 group"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={ind.image}
                  alt={ind.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1000";
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#121217] via-transparent to-transparent opacity-80" />
                
                {/* Sector Badge */}
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                  <div className="bg-[#0A0A0B]/90 border border-[#C5A267]/40 text-white text-xs font-bold px-3 py-1.5 rounded-lg backdrop-blur flex items-center gap-2">
                    {getIcon(ind.icon)}
                    <span>{ind.name}</span>
                  </div>
                </div>
              </div>

              {/* Description & Action */}
              <div className="p-5 space-y-3">
                <p className="text-xs text-slate-400 leading-relaxed font-light">
                  {ind.desc}
                </p>

                <button
                  onClick={onOpenInspection}
                  className="inline-flex items-center gap-1.5 text-xs text-[#38BDF8] hover:text-[#C5A267] font-bold group-hover:translate-x-1 transition-all cursor-pointer"
                >
                  <span>Request Sector Proposal</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

