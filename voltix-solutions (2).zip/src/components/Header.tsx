import React, { useState } from 'react';
import { Phone, Mail, MapPin, Menu, X, Clock, MessageSquare, Zap, HardHat, Shield } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';

export type PageId = 'home' | 'about' | 'services' | 'solar' | 'cctv' | 'why-us' | 'industries' | 'contact';

interface HeaderProps {
  currentPage: PageId;
  onPageChange: (page: PageId) => void;
  onOpenInspection: () => void;
  onOpenQuote: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  onPageChange,
  onOpenInspection,
  onOpenQuote
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: PageId; label: string; icon?: React.ReactNode; isBadge?: boolean }[] = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'services', label: 'Services' },
    { id: 'solar', label: 'Solar Calculator', isBadge: true },
    { id: 'cctv', label: 'CCTV & Security' },
    { id: 'why-us', label: 'Why Choose Us' },
    { id: 'industries', label: 'Industries' },
    { id: 'contact', label: 'Contact Us' },
  ];

  const handleNavClick = (id: PageId) => {
    onPageChange(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-[#0A0A0B] text-slate-100 border-b border-[#2A2A32] shadow-2xl">
      {/* Top Bar - Phone, Email & Support */}
      <div className="bg-[#050506] text-xs py-2 px-4 border-b border-[#1E1E24] text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4">
            <a 
              href={`tel:${COMPANY_INFO.contact.phone1Raw}`} 
              className="flex items-center gap-1.5 hover:text-[#C5A267] transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span className="font-mono text-slate-300">{COMPANY_INFO.contact.phone1}</span>
            </a>
            <a 
              href={`tel:${COMPANY_INFO.contact.phone2Raw}`} 
              className="flex items-center gap-1.5 hover:text-[#C5A267] transition-colors hidden md:flex"
            >
              <Phone className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span className="font-mono text-slate-300">{COMPANY_INFO.contact.phone2}</span>
            </a>
            <a 
              href={`mailto:${COMPANY_INFO.contact.email}`} 
              className="flex items-center gap-1.5 hover:text-[#C5A267] transition-colors hidden lg:flex"
            >
              <Mail className="w-3.5 h-3.5 text-[#C5A267]" />
              <span>{COMPANY_INFO.contact.email}</span>
            </a>
            <div className="flex items-center gap-1.5 text-slate-500 hidden xl:flex">
              <MapPin className="w-3.5 h-3.5 text-rose-400" />
              <span>Korangi, Karachi, Pakistan</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-emerald-400 font-medium text-[11px]">
              <Clock className="w-3.5 h-3.5" />
              <span>24/7 Emergency Dispatch</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        
        {/* Brand Logo */}
        <div 
          onClick={() => handleNavClick('home')} 
          className="cursor-pointer flex items-center gap-3 group"
        >
          <div className="w-10 h-10 bg-gradient-to-br from-[#1A1A22] to-[#0A0A0B] rounded-xl p-0.5 border border-[#C5A267]/50 flex items-center justify-center shadow-lg group-hover:border-[#C5A267] transition-all">
            <div className="w-full h-full bg-[#0F0F12] rounded-[10px] flex items-center justify-center relative overflow-hidden">
              <Zap className="w-5 h-5 text-[#C5A267] fill-[#C5A267]/20" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xl font-black tracking-wider text-white font-serif">
                VOLTIX
              </span>
              <span className="text-xl font-extrabold tracking-wider text-[#38BDF8]">
                SOLUTIONS
              </span>
            </div>
            <p className="text-[9px] uppercase tracking-widest text-[#C5A267] font-semibold -mt-1">
              Powering Innovation • Delivering Excellence
            </p>
          </div>
        </div>

        {/* Desktop Nav Items (Multi-Page Tabs) */}
        <nav className="hidden lg:flex items-center gap-1.5 text-xs font-semibold">
          {navItems.map((item) => {
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-3 py-2 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#181822] text-[#C5A267] border border-[#C5A267]/40 shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-[#121217]'
                }`}
              >
                {item.isBadge && <Zap className="w-3 h-3 text-[#C5A267] fill-[#C5A267]" />}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Action CTAs */}
        <div className="hidden md:flex items-center gap-2.5">
          <button
            onClick={onOpenQuote}
            className="bg-[#181822] hover:bg-[#22222E] text-slate-200 px-3.5 py-2 rounded-lg text-xs font-semibold border border-[#383845] transition-all cursor-pointer shadow"
          >
            Instant Estimate
          </button>
          <button
            onClick={onOpenInspection}
            className="bg-gradient-to-r from-[#C5A267] to-[#A88448] hover:from-[#D8B77D] hover:to-[#B89458] text-[#0A0A0B] px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-1.5"
          >
            <HardHat className="w-4 h-4" />
            <span>Book Site Survey</span>
          </button>
        </div>

        {/* Mobile Hamburger Menu Toggle */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-2 text-slate-300 hover:text-white bg-[#121217] rounded-lg border border-[#2A2A32]"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Page Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0A0A0B] border-b border-[#2A2A32] px-4 py-4 space-y-2 animate-fadeIn">
          <div className="text-[10px] uppercase tracking-widest text-[#C5A267] font-bold px-3 pb-1 border-b border-[#1E1E24]">
            Select Page View
          </div>

          <div className="grid grid-cols-2 gap-1.5 pt-1">
            {navItems.map((item) => {
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`text-left py-2.5 px-3 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#C5A267] text-[#0A0A0B] font-bold'
                      : 'bg-[#121217] text-slate-300 hover:text-white hover:bg-[#181820] border border-[#2A2A32]'
                  }`}
                >
                  {item.isBadge && <Zap className="w-3.5 h-3.5 fill-current" />}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-[#1E1E24] flex flex-col gap-2">
            <button
              onClick={() => { setMobileMenuOpen(false); onOpenInspection(); }}
              className="w-full bg-[#C5A267] text-[#0A0A0B] py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 shadow cursor-pointer"
            >
              <HardHat className="w-4 h-4" />
              <span>Book Technical Site Survey</span>
            </button>
            <a
              href={`https://wa.me/${COMPANY_INFO.contact.whatsapp}?text=Hello%20Voltix%20Solutions,%20I%20would%20like%20to%20inquire%20about%20your%20engineering%20services.`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-2 cursor-pointer shadow"
            >
              <MessageSquare className="w-4 h-4" />
              <span>WhatsApp Direct Engineering Chat</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

