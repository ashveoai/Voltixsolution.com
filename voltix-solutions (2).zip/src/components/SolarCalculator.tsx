import React, { useState } from 'react';
import { Sun, Zap, Calculator, CheckCircle2, ArrowRight, MessageSquare } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';

interface SolarCalculatorProps {
  onOpenInspection: () => void;
}

export const SolarCalculator: React.FC<SolarCalculatorProps> = ({ onOpenInspection }) => {
  const [monthlyBill, setMonthlyBill] = useState<number>(60000);
  const [systemType, setSystemType] = useState<'hybrid' | 'ongrid' | 'offgrid'>('hybrid');
  const [daytimePercent, setDaytimePercent] = useState<number>(70);

  // Constants based on current Pakistan solar economics
  const tariffPerUnit = 65; // Average PKR per kWh
  const solarGenPerKwPerMonth = 120; // kWh produced by 1kW in Karachi per month
  const panelWattage = 585; // Watts per panel
  const costPerKwPkr = 165000; // Average turnkey PKR per kW

  // Calculations
  const unitsConsumed = Math.round(monthlyBill / tariffPerUnit);
  const offsetUnits = Math.round(unitsConsumed * (daytimePercent / 100));
  const rawKwNeeded = offsetUnits / solarGenPerKwPerMonth;
  
  const recommendedKw = Math.max(3, Math.ceil(rawKwNeeded));
  const panelCount = Math.ceil((recommendedKw * 1000) / panelWattage);
  
  const estimatedCostMin = Math.round(recommendedKw * costPerKwPkr * 0.95);
  const estimatedCostMax = Math.round(recommendedKw * costPerKwPkr * 1.08);

  const monthlySavings = Math.min(monthlyBill * 0.9, Math.round(offsetUnits * tariffPerUnit));
  const yearlySavings = monthlySavings * 12;
  const paybackYears = (estimatedCostMin / yearlySavings).toFixed(1);

  const formatPkr = (val: number) => {
    return "Rs. " + val.toLocaleString('en-PK');
  };

  const generateWhatsAppMessage = () => {
    const text = `Hello Voltix Solutions! I calculated my Solar requirement on your website:
- Monthly Bill: ${formatPkr(monthlyBill)}
- Recommended System: ${recommendedKw} kW (${systemType.toUpperCase()})
- Tier-1 Solar Panels: ${panelCount} Panels (585W)
- Est. Monthly Savings: ${formatPkr(monthlySavings)}
- Est. Investment: ${formatPkr(estimatedCostMin)} - ${formatPkr(estimatedCostMax)}

Please provide a formal engineering quote with K-Electric Net Metering support.`;
    return `https://wa.me/${COMPANY_INFO.contact.whatsapp}?text=${encodeURIComponent(text)}`;
  };

  return (
    <section className="py-16 md:py-24 bg-[#0A0A0B] text-slate-100 relative border-b border-[#2A2A32]">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Title Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 bg-[#121217] border border-[#C5A267]/40 text-[#C5A267] text-xs font-bold uppercase px-3.5 py-1 rounded-full">
            <Sun className="w-4 h-4 fill-[#C5A267]" />
            <span>Interactive ROI & Capacity Engine</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white font-serif">
            SOLAR SYSTEM <span className="text-[#C5A267]">ROI & SAVINGS CALCULATOR</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base font-light">
            Calculate your custom solar capacity, estimated cost, payback duration, and monthly bill reduction for Karachi & Pakistan.
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-[#C5A267] to-[#38BDF8] mx-auto rounded-full" />
        </div>

        <div className="grid lg:grid-cols-12 gap-8 items-start">
          
          {/* Controls Panel */}
          <div className="lg:col-span-5 bg-[#121217] border border-[#2A2A32] rounded-2xl p-6 shadow-2xl space-y-6">
            <h3 className="text-lg font-bold text-white font-serif flex items-center gap-2 border-b border-[#2A2A32] pb-3">
              <Calculator className="w-5 h-5 text-[#C5A267]" />
              <span>Electricity & Bill Inputs</span>
            </h3>

            {/* Slider: Monthly Bill */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <label className="text-slate-300 font-medium">Average Monthly Bill (PKR):</label>
                <span className="text-[#C5A267] font-bold text-sm bg-[#181822] px-3 py-1 rounded-lg border border-[#C5A267]/30 font-mono">
                  {formatPkr(monthlyBill)}
                </span>
              </div>
              <input
                type="range"
                min="15000"
                max="500000"
                step="5000"
                value={monthlyBill}
                onChange={(e) => setMonthlyBill(Number(e.target.value))}
                className="w-full accent-[#C5A267] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>Rs. 15,000</span>
                <span>Rs. 250,000</span>
                <span>Rs. 500,000+</span>
              </div>
            </div>

            {/* System Type Selector */}
            <div className="space-y-2">
              <label className="text-slate-300 text-xs font-semibold">Preferred System Configuration:</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setSystemType('hybrid')}
                  className={`p-2.5 rounded-xl border text-[11px] font-bold text-center cursor-pointer transition-all ${
                    systemType === 'hybrid'
                      ? 'bg-[#C5A267] text-[#0A0A0B] border-[#C5A267] shadow'
                      : 'bg-[#181822] text-slate-300 border-[#2A2A32] hover:bg-[#22222E]'
                  }`}
                >
                  Hybrid (Net Meter + Battery)
                </button>
                <button
                  type="button"
                  onClick={() => setSystemType('ongrid')}
                  className={`p-2.5 rounded-xl border text-[11px] font-bold text-center cursor-pointer transition-all ${
                    systemType === 'ongrid'
                      ? 'bg-[#38BDF8] text-[#0A0A0B] border-[#38BDF8] shadow'
                      : 'bg-[#181822] text-slate-300 border-[#2A2A32] hover:bg-[#22222E]'
                  }`}
                >
                  On-Grid (Net Metering)
                </button>
                <button
                  type="button"
                  onClick={() => setSystemType('offgrid')}
                  className={`p-2.5 rounded-xl border text-[11px] font-bold text-center cursor-pointer transition-all ${
                    systemType === 'offgrid'
                      ? 'bg-emerald-600 text-white border-emerald-500 shadow'
                      : 'bg-[#181822] text-slate-300 border-[#2A2A32] hover:bg-[#22222E]'
                  }`}
                >
                  Off-Grid (Battery Only)
                </button>
              </div>
            </div>

            {/* Daytime Usage % */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <label className="text-slate-300 font-medium">Daytime Usage Share:</label>
                <span className="text-[#38BDF8] font-bold text-xs bg-[#181822] px-2.5 py-0.5 rounded border border-[#2A2A32]">
                  {daytimePercent}%
                </span>
              </div>
              <input
                type="range"
                min="30"
                max="100"
                step="5"
                value={daytimePercent}
                onChange={(e) => setDaytimePercent(Number(e.target.value))}
                className="w-full accent-[#38BDF8] cursor-pointer"
              />
              <p className="text-[11px] text-slate-400">
                Higher daytime load (ACs, pumps, machinery) increases solar direct self-consumption efficiency.
              </p>
            </div>

            <div className="pt-3 border-t border-[#2A2A32] text-xs text-slate-300 space-y-1.5 font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">Monthly Consumption:</span>
                <strong className="text-white">{unitsConsumed} Units (kWh)</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Karachi Tariff Benchmark:</span>
                <strong className="text-white">~Rs. {tariffPerUnit}/Unit</strong>
              </div>
            </div>

          </div>

          {/* Results Summary Card */}
          <div className="lg:col-span-7 bg-[#121217] border border-[#C5A267]/60 rounded-2xl p-6 shadow-2xl space-y-6">
            
            <div className="flex items-center justify-between border-b border-[#2A2A32] pb-4">
              <div>
                <span className="text-xs uppercase font-bold text-[#C5A267] tracking-wider">
                  Recommended Technical Specs
                </span>
                <h3 className="text-2xl sm:text-3xl font-black text-white font-serif">
                  {recommendedKw} kW <span className="text-[#38BDF8] text-lg font-sans">Solar Solution</span>
                </h3>
              </div>
              <div className="w-12 h-12 rounded-xl bg-[#C5A267]/20 border border-[#C5A267] flex items-center justify-center text-[#C5A267]">
                <Zap className="w-6 h-6 fill-[#C5A267]" />
              </div>
            </div>

            {/* Key Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              
              <div className="bg-[#0A0A0B] border border-[#2A2A32] p-4 rounded-xl">
                <div className="text-[11px] text-slate-400 font-medium">Solar Panels Required</div>
                <div className="text-xl sm:text-2xl font-black text-[#C5A267] font-serif mt-1">
                  {panelCount} <span className="text-xs font-sans text-slate-300">Panels</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Tier-1 585W N-Type</div>
              </div>

              <div className="bg-[#0A0A0B] border border-[#2A2A32] p-4 rounded-xl">
                <div className="text-[11px] text-slate-400 font-medium">Est. Monthly Savings</div>
                <div className="text-xl sm:text-2xl font-black text-emerald-400 font-serif mt-1">
                  {formatPkr(monthlySavings)}
                </div>
                <div className="text-[10px] text-emerald-400 mt-1">Up to 85% Reduction</div>
              </div>

              <div className="bg-[#0A0A0B] border border-[#2A2A32] p-4 rounded-xl col-span-2 sm:col-span-1">
                <div className="text-[11px] text-slate-400 font-medium">Payback Period</div>
                <div className="text-xl sm:text-2xl font-black text-[#38BDF8] font-serif mt-1">
                  ~{paybackYears} <span className="text-xs font-sans text-slate-300">Years</span>
                </div>
                <div className="text-[10px] text-[#38BDF8] mt-1">25+ Year Solar Life</div>
              </div>

            </div>

            {/* Turnkey Cost Estimate Box */}
            <div className="bg-[#181822] border border-[#2A2A32] rounded-xl p-4 text-center space-y-1">
              <div className="text-xs text-slate-400 uppercase font-bold tracking-wider">
                Estimated Turnkey Project Investment (PKR)
              </div>
              <div className="text-2xl sm:text-3xl font-black text-white font-serif font-mono">
                {formatPkr(estimatedCostMin)} - {formatPkr(estimatedCostMax)}
              </div>
              <p className="text-[11px] text-slate-400">
                Includes Tier-1 Panels, High-Efficiency Inverter, Mounting Structure, Wiring, Installation & K-Electric Green Meter Support.
              </p>
            </div>

            {/* Checklist items */}
            <div className="grid sm:grid-cols-2 gap-2 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>25-Year Panel Performance Warranty</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>5-Year Inverter Replacement Warranty</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Net Metering Paperwork & K-Electric Approval</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>On-Site Civil & Electrical Supervision</span>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <a
                href={generateWhatsAppMessage()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-xl text-xs sm:text-sm transition-all text-center flex items-center justify-center gap-2 shadow-lg"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Send Result to WhatsApp</span>
              </a>

              <button
                onClick={onOpenInspection}
                className="w-full sm:w-auto bg-[#C5A267] hover:bg-[#D8B77D] text-[#0A0A0B] font-extrabold py-3 px-5 rounded-xl text-xs sm:text-sm transition-all text-center flex items-center justify-center gap-2 shadow"
              >
                <span>Request Free Technical Survey</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};

