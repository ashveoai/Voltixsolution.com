import React from 'react';
import { Target, Eye, Shield, Award, Clock, ThumbsUp, HardHat } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';

export const AboutUs: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-[#0A0A0B] text-slate-100 relative border-b border-[#2A2A32]">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 bg-[#121217] border border-[#C5A267]/40 text-[#C5A267] text-xs uppercase font-bold px-3.5 py-1 rounded-full">
            <HardHat className="w-3.5 h-3.5" />
            <span>Corporate Overview & Engineering Legacy</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white font-serif">
            ABOUT <span className="text-[#C5A267]">VOLTIX SOLUTIONS</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-[#C5A267] to-[#38BDF8] mx-auto rounded-full" />
        </div>

        {/* Corporate Overview Card */}
        <div className="bg-[#121217] border border-[#2A2A32] rounded-2xl p-6 md:p-8 shadow-xl space-y-8 mb-12">
          <div className="grid md:grid-cols-12 gap-8 items-center">
            
            <div className="md:col-span-7 space-y-4">
              <h3 className="text-2xl font-bold text-white flex items-center gap-2 font-serif">
                <Shield className="w-6 h-6 text-[#C5A267]" />
                Integrated MEP & Solar Engineering Platform
              </h3>
              <p className="text-slate-300 text-sm md:text-base leading-relaxed font-light">
                {COMPANY_INFO.aboutEnglish}
              </p>
              <div className="border-l-2 border-[#C5A267] pl-4 py-2 bg-[#181822] rounded-r-lg">
                <p className="text-xs text-slate-300 italic">
                  Operated by a team of PEC-certified engineering professionals serving residential estates, commercial plazas, textile mills, manufacturing plants, and high-rise construction sites across Karachi and Pakistan.
                </p>
              </div>
            </div>

            <div className="md:col-span-5 relative h-64 rounded-xl overflow-hidden border border-[#2A2A32]">
              <img
                src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=800"
                alt="Voltix Electrical and Solar Engineers"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B] via-transparent to-transparent opacity-80" />
              <div className="absolute bottom-3 left-3 right-3 bg-[#0A0A0B]/90 border border-[#C5A267]/40 p-2.5 rounded-lg text-center backdrop-blur">
                <span className="text-xs font-bold text-[#C5A267]">100% Certified Safety Standards & PEC Guidelines</span>
              </div>
            </div>

          </div>

          {/* Company Priorities Highlight */}
          <div className="pt-6 border-t border-[#2A2A32]">
            <h4 className="text-center text-xs uppercase tracking-wider font-bold text-[#C5A267] mb-6">
              Our Non-Negotiable Core Engineering Pillars:
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              <div className="bg-[#181822] border border-[#2A2A32] p-4 rounded-xl hover:border-[#C5A267]/50 transition-all">
                <Award className="w-6 h-6 text-[#C5A267] mx-auto mb-2" />
                <div className="text-sm font-bold text-white">Turnkey Precision</div>
                <div className="text-xs text-slate-400 mt-1">International Specs</div>
              </div>
              <div className="bg-[#181822] border border-[#2A2A32] p-4 rounded-xl hover:border-[#38BDF8]/50 transition-all">
                <Shield className="w-6 h-6 text-[#38BDF8] mx-auto mb-2" />
                <div className="text-sm font-bold text-white">Fail-Safe Standards</div>
                <div className="text-xs text-slate-400 mt-1">IEEE & NFPA Compliant</div>
              </div>
              <div className="bg-[#181822] border border-[#2A2A32] p-4 rounded-xl hover:border-emerald-400/50 transition-all">
                <Clock className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
                <div className="text-sm font-bold text-white">On-Schedule Delivery</div>
                <div className="text-xs text-slate-400 mt-1">Guaranteed Deadlines</div>
              </div>
              <div className="bg-[#181822] border border-[#2A2A32] p-4 rounded-xl hover:border-amber-400/50 transition-all">
                <ThumbsUp className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                <div className="text-sm font-bold text-white">Lifetime Support</div>
                <div className="text-xs text-slate-400 mt-1">24/7 SLA Backing</div>
              </div>
            </div>
          </div>
        </div>

        {/* Mission & Vision Side-by-Side Cards */}
        <div className="grid md:grid-cols-2 gap-8">
          
          {/* Our Mission */}
          <div className="bg-[#121217] border border-[#2A2A32] hover:border-[#38BDF8]/60 rounded-2xl p-6 sm:p-8 space-y-4 transition-all shadow-xl group">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#38BDF8]/10 border border-[#38BDF8]/40 flex items-center justify-center text-[#38BDF8]">
                <Target className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white font-serif">Our Mission</h3>
                <p className="text-xs text-[#38BDF8] uppercase tracking-wider font-semibold">Engineering Excellence</p>
              </div>
            </div>
            
            <p className="text-slate-300 text-sm leading-relaxed font-light">
              {COMPANY_INFO.mission}
            </p>

            <div className="relative h-48 rounded-xl overflow-hidden mt-4 border border-[#2A2A32]">
              <img
                src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=800"
                alt="Engineers executing technical project"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B] to-transparent opacity-70" />
            </div>
          </div>

          {/* Our Vision */}
          <div className="bg-[#121217] border border-[#2A2A32] hover:border-[#C5A267]/60 rounded-2xl p-6 sm:p-8 space-y-4 transition-all shadow-xl group">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#C5A267]/10 border border-[#C5A267]/40 flex items-center justify-center text-[#C5A267]">
                <Eye className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white font-serif">Our Vision</h3>
                <p className="text-xs text-[#C5A267] uppercase tracking-wider font-semibold">Sustainable Future</p>
              </div>
            </div>
            
            <p className="text-slate-300 text-sm leading-relaxed font-light">
              {COMPANY_INFO.vision}
            </p>

            <div className="relative h-48 rounded-xl overflow-hidden mt-4 border border-[#2A2A32]">
              <img
                src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800"
                alt="Modern corporate buildings engineered by Voltix"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B] to-transparent opacity-70" />
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};

