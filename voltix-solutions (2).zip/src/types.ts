export type Language = 'en';

export interface ServiceDetail {
  id: string;
  title: string;
  category: 'electrical' | 'solar' | 'engineering' | 'plumbing' | 'hvac' | 'fire-safety' | 'cctv' | 'maintenance';
  shortDesc: string;
  iconName: string;
  image: string;
  features: string[];
  popularFor: string[];
  pricingEstimate?: string;
}

export interface Industry {
  id: string;
  name: string;
  desc: string;
  image: string;
  icon: string;
}

export interface ValueProp {
  id: string;
  title: string;
  desc: string;
  icon: string;
}

export interface SiteInspectionRequest {
  fullName: string;
  phone: string;
  email: string;
  serviceType: string;
  propertyType: string;
  address: string;
  preferredDate: string;
  preferredTime: string;
  notes: string;
  urgency: 'routine' | 'urgent' | 'emergency';
}

export interface SolarCalculationResult {
  monthlyBill: number;
  monthlyUnits: number;
  recommendedKw: number;
  panelCount: number;
  inverterCapacity: string;
  estimatedCostMin: number;
  estimatedCostMax: number;
  monthlySavings: number;
  yearlySavings: number;
  paybackYears: number;
  co2SavedTons: number;
}

export interface QuoteItem {
  serviceId: string;
  serviceName: string;
  quantity: number;
  unit: string;
  estimatedRate: number;
}
