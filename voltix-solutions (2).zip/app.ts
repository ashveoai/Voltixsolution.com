import express from "express";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

export const app = express();

app.use(express.json());

// Gemini AI Setup (lazy init pattern)
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({ apiKey });
}

// In-memory inquiry store
const inquiriesList: Array<{
  id: string;
  name: string;
  phone: string;
  email?: string;
  message: string;
  timestamp: string;
}> = [];

// Submit Inquiry API
app.post("/api/inquiries", (req, res) => {
  const { name, phone, email, message } = req.body;
  if (!name || !phone || !message) {
    return res.status(400).json({ error: "Name, phone, and message are required." });
  }

  const newInquiry = {
    id: "INQ-" + Date.now(),
    name,
    phone,
    email: email || "N/A",
    message,
    timestamp: new Date().toISOString()
  };

  inquiriesList.unshift(newInquiry);

  return res.json({
    success: true,
    message: "Inquiry stored successfully",
    inquiry: newInquiry
  });
});

// Retrieve Inquiries API (for web owner / admin team)
app.get("/api/inquiries", (_req, res) => {
  res.json({
    total: inquiriesList.length,
    inquiries: inquiriesList
  });
});

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", company: "Voltix Solutions" });
});

// Helper smart engineering assistant for local fallback
function generateSmartLocalReply(userQuery: string): string {
  const query = userQuery.toLowerCase();

  // Solar calculations
  if (query.includes('solar') || query.includes('bill') || query.includes('panel') || query.includes('unit') || query.includes('kw') || query.includes('net meter')) {
    const numbers = userQuery.match(/\d+/g);
    let bill = 60000;
    if (numbers && numbers.length > 0) {
      const parsed = parseInt(numbers[0], 10);
      if (parsed > 1000) bill = parsed;
    }
    const estimatedUnits = Math.round(bill / 65);
    const recommendedKw = Math.max(3, Math.ceil((estimatedUnits * 0.7) / 120));
    const panels = Math.ceil((recommendedKw * 1000) / 585);
    const costMin = Math.round(recommendedKw * 165000 * 0.95);
    const costMax = Math.round(recommendedKw * 165000 * 1.08);
    const savings = Math.round(bill * 0.85);

    return `Solar Engineering Recommendation for Voltix Solutions:
• Recommended Capacity: ${recommendedKw} kW Hybrid / On-Grid System
• Solar Panels: ${panels}x Tier-1 N-Type Mono PERC (585W)
• Estimated Turnkey Cost: PKR ${costMin.toLocaleString('en-PK')} – PKR ${costMax.toLocaleString('en-PK')}
• Monthly Savings: ~PKR ${savings.toLocaleString('en-PK')} (Up to 85% bill reduction)
• Includes: High-efficiency Inverter, Elevated Mounting Structure fabrication, K-Electric Net Metering Green Meter filing, and 25-Year Panel Performance Warranty.`;
  }

  // CCTV & Security
  if (query.includes('cctv') || query.includes('camera') || query.includes('security') || query.includes('nvr') || query.includes('dvr')) {
    const numbers = userQuery.match(/\d+/g);
    let cams = 4;
    if (numbers && numbers.length > 0) {
      const parsed = parseInt(numbers[0], 10);
      if (parsed > 0 && parsed < 128) cams = parsed;
    }
    const cost = cams * 9500 + 15000;
    return `Voltix CCTV & Surveillance Engineering Setup:
• Camera System: ${cams}x 5MP IP Full Night Vision Weatherproof Cameras
• Recording Unit: ${cams <= 4 ? 4 : cams <= 8 ? 8 : 16}-Channel 4K NVR with ${cams <= 8 ? '2TB' : '4TB'} Surveillance HDD (30-day continuous loop)
• Remote Smartphone App: Full live view & playback access configured on iOS & Android
• Estimated Turnkey Package: PKR ${cost.toLocaleString('en-PK')} (includes CAT6 cabling, connectors, power supplies & installation)
• Warranty: 1-Year replacement warranty on cameras & NVR hardware.`;
  }

  // HVAC / Air Conditioning
  if (query.includes('ac') || query.includes('hvac') || query.includes('cooling') || query.includes('ton') || query.includes('chiller') || query.includes('room')) {
    return `Voltix HVAC & AC Engineering Guidance:
• Tonnage Sizing Rule: ~1.0 Ton per 120-150 sq. ft. room space (or 1.5 Ton for 180-220 sq. ft.).
• Recommended Setup: Inverter Heat & Cool Split Units for maximum energy efficiency.
• Installation Rate: Standard mounting & piping starting from PKR 8,500/unit.
• Ducting & VRF Systems: Custom airflow layout & CFM load calculation available for commercial spaces and server rooms.`;
  }

  // Electrical & DB Panels
  if (query.includes('electric') || query.includes('db') || query.includes('wiring') || query.includes('panel') || query.includes('generator') || query.includes('fault')) {
    return `Voltix Electrical Engineering Services:
• Distribution Boards (DB): Custom fabrication & installation with Schneider/Siemens breakers from PKR 25,000/panel.
• Load Audit & Phase Balancing: Full thermal imaging & load distribution to prevent breaker trips & electrical hazards.
• Wiring & Conduits: Flame-retardant copper cables (Pakistan Cables / Pioneer Cables) for residential, commercial & industrial plants.
• Generator Backup: ATS (Automatic Transfer Switch) & AMF panel integration for seamless power transition.`;
  }

  // Fire Safety
  if (query.includes('fire') || query.includes('alarm') || query.includes('hydrant') || query.includes('extinguisher') || query.includes('smoke')) {
    return `Voltix Fire Safety Solutions:
• Addressable & Conventional Fire Alarm Panels with optical smoke & heat detectors.
• Fire Hydrant Ring Mains, jockey pump sets, and sprinklers for industrial compliance.
• Extinguisher Supply & Refilling: Dry Chemical Powder (DCP), CO2, and Foam cylinders inspected and refilled to safety standards.
• Packages start from PKR 45,000 for standard commercial premises.`;
  }

  // Default company response
  return `Welcome to Voltix Solutions!
We are Karachi's premier technical engineering firm offering end-to-end solutions:
1. Electrical Systems & DB Panels
2. Turnkey Solar Systems with Net Metering
3. HVAC & Air Conditioning Installation
4. CCTV Surveillance & Access Control
5. Fire Safety Systems & Hydrants
6. Plumbing & Industrial Maintenance

Would you like to calculate a custom Solar ROI, request a CCTV package, or book a free technical site survey with our engineers?`;
}

// AI Engineering Assistant endpoint
app.post("/api/ai-consultant", async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) {
      return res.status(400).json({ error: "Message is required" });
    }

    const ai = getGenAI();
    if (!ai) {
      return res.json({ reply: generateSmartLocalReply(message) });
    }

    const systemPrompt = `You are the Lead Senior Engineering Consultant for VOLTIX SOLUTIONS, a premier technical engineering firm in Karachi, Pakistan.
Always reply in clear, professional English.

Company Overview:
- Services: Electrical (wiring, DB panels, phase balancing, generators), Solar Solutions (On-Grid, Off-Grid, Hybrid, Net Metering), Engineering Consultations (MEP, load audits, site supervision), Plumbing (water supply, drainage, leak detection), HVAC / AC Services (Inverter AC, ductwork, VRF), Fire Safety (addressable alarms, hydrants, refilling), CCTV & Security (HD/IP cameras, 4K NVR, mobile live monitoring), General Maintenance (AMC).
- Address: Plot # A-150, Behind Korangi No.6 Market Opp. Islamia Ground Karachi
- Phone: +92 300 2667840 / +92 304 2510042
- Email: voltixsolutionpvtpk@gmail.com

Instructions:
1. Provide structured, highly accurate, professional engineering answers in clear English.
2. If the query asks about solar, provide specific estimated kW, panel counts, costs in PKR, and monthly savings.
3. If the query asks about CCTV, provide camera package specs, NVR drive size, and PKR estimates.
4. Keep answers concise, informative, well-formatted, and under 180 words.
5. Encourage booking a free site survey with Voltix Solutions engineers.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        { role: "user", parts: [{ text: systemPrompt + "\n\nUser Question: " + message }] }
      ]
    });

    const reply = response.text || generateSmartLocalReply(message);
    return res.json({ reply });
  } catch (err: any) {
    console.error("AI Assistant Error:", err);
    return res.json({ reply: generateSmartLocalReply(req.body.message || "") });
  }
});
